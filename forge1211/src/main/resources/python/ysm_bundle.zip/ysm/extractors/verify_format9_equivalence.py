from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
from collections import Counter
from pathlib import Path
from typing import Any

from extractors.bom_v3_end_to_end_parser import decode_bom_v3, export_bom_v3_assets
from bom_v3_legacy_sections import _png_pixels_equal
from extractors.bom_v3_source_oracle import find_best_source_oracle


MODEL_FILES = (
    ("main.json", "models/main.json"),
    ("arm.json", "models/arm.json"),
    ("arrow.json", "models/arrow.json"),
)

ANIMATION_FILES = (
    ("main.animation.json", "animations/main.animation.json"),
    ("extra.animation.json", "animations/extra.animation.json"),
    ("tac.animation.json", "animations/tac.animation.json"),
    ("carryon.animation.json", "animations/carryon.animation.json"),
    ("arrow.animation.json", "animations/arrow.animation.json"),
)


def _round_num(value: Any) -> Any:
    if isinstance(value, float):
        return round(value, 5)
    return value


def _canon_json(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _canon_json(value[key]) for key in sorted(value)}
    if isinstance(value, list):
        return [_canon_json(item) for item in value]
    return _round_num(value)


def _canon_model_json(obj: dict[str, Any]) -> dict[str, Any]:
    canon = _canon_json(obj)
    geometry = canon.get("minecraft:geometry")
    if not isinstance(geometry, list):
        return canon
    normalized_geometry: list[dict[str, Any]] = []
    for geom in geometry:
        if not isinstance(geom, dict):
            normalized_geometry.append(geom)
            continue
        bones = geom.get("bones")
        if isinstance(bones, list):
            geom = dict(geom)
            geom["bones"] = sorted(
                [bone for bone in bones if isinstance(bone, dict)],
                key=lambda bone: str(bone.get("name", "")),
            )
        normalized_geometry.append(geom)
    canon["minecraft:geometry"] = normalized_geometry
    return canon


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _json_equal(extracted: Path, source: Path, *, model: bool) -> bool:
    if not extracted.exists() or not source.exists():
        return extracted.exists() == source.exists()
    out_obj = _load_json(extracted)
    src_obj = _load_json(source)
    if model:
        return _canon_model_json(out_obj) == _canon_model_json(src_obj)
    return _canon_json(out_obj) == _canon_json(src_obj)


def _verify_json_group(
    out_dir: Path,
    source_root: Path,
    pairs: tuple[tuple[str, str], ...],
    *,
    model: bool,
) -> list[str]:
    mismatches: list[str] = []
    for out_name, src_rel in pairs:
        out_path = out_dir / out_name
        src_path = source_root / src_rel
        if not _json_equal(out_path, src_path, model=model):
            mismatches.append(f"{out_name} != {src_rel}")
    return mismatches


def _verify_textures(out_dir: Path, source_root: Path) -> list[str]:
    out_pngs = sorted(path for path in out_dir.glob("*.png") if path.is_file())
    src_pngs = sorted(path for path in (source_root / "textures").glob("*.png") if path.is_file())
    if len(out_pngs) != len(src_pngs):
        return [f"textures mismatch: extracted={len(out_pngs)} source={len(src_pngs)}"]
    unmatched = list(src_pngs)
    for out_path in out_pngs:
        out_bytes = out_path.read_bytes()
        match_idx = None
        for idx, src_path in enumerate(unmatched):
            if _png_pixels_equal(out_bytes, src_path.read_bytes()):
                match_idx = idx
                break
        if match_idx is None:
            return [f"textures mismatch: no pixel-equivalent match for {out_path.name}"]
        unmatched.pop(match_idx)
    return []


def verify_format9(ysm_path: Path, source_root: Path | None) -> int:
    if source_root is None:
        best_dir, match_count, asset_count = find_best_source_oracle(ysm_path)
        if best_dir is None or match_count == 0:
            raise SystemExit("no matching nearby source tree found")
        source_root = best_dir
        print(f"auto_source_root: {source_root} ({match_count}/{asset_count})")

    result = decode_bom_v3(ysm_path)
    if result.codec_format != 9:
        raise SystemExit(f"expected format 9, got {result.codec_format!r}")

    with contextlib.redirect_stdout(io.StringIO()):
        out_dir = export_bom_v3_assets(
            ysm_path,
            result.codec_format,
            scan_assets=False,
            dump_assets=False,
            dump_folder=True,
            debug=False,
        )

    model_mismatches = _verify_json_group(out_dir, source_root, MODEL_FILES, model=True)
    animation_mismatches = _verify_json_group(out_dir, source_root, ANIMATION_FILES, model=False)
    texture_mismatches = _verify_textures(out_dir, source_root)
    all_mismatches = model_mismatches + animation_mismatches + texture_mismatches

    print(f"file: {ysm_path}")
    print(f"source_root: {source_root}")
    print(f"dump_folder: {out_dir}")
    print(f"models_equal: {str(not model_mismatches).lower()}")
    print(f"animations_equal: {str(not animation_mismatches).lower()}")
    print(f"textures_equal: {str(not texture_mismatches).lower()}")
    print(f"overall_equivalent: {str(not all_mismatches).lower()}")

    if all_mismatches:
        for item in all_mismatches:
            print(f"mismatch: {item}")
        return 1
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Verify oracle-free format 9 extraction against a paired source tree."
    )
    ap.add_argument("ysm_path", type=Path)
    ap.add_argument(
        "--source-root",
        type=Path,
        help="paired source tree; if omitted, auto-discover the best nearby source-oracle candidate",
    )
    args = ap.parse_args()
    return verify_format9(args.ysm_path, args.source_root)


if __name__ == "__main__":
    raise SystemExit(main())
