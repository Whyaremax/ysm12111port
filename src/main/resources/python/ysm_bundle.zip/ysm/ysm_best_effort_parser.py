from __future__ import annotations

import argparse
from pathlib import Path
import re

from compact_v2_guided_probe import dump_probe_candidate, probe_compact_entry
from ysgp_compact_v2_parser import extract_entry_payloads, parse_compact_v2_file
from ysgp_container_scanner import scan_file
from ysgp_end_to_end_extractor import (
    CandidateResult,
    dump_candidate,
    enumerate_candidates,
    load_input,
)
from ysgp_outer_v3_static import MAGIC_PREFIX, parse_outer_v3_layout
from ysgp_v3_exact_probe import (
    V3ExactCandidate,
    dump_v3_candidate,
    enumerate_v3_exact_candidates,
    is_valid_v3_stream_candidate,
    parse_v3_exact_input,
)
from ysm_v3_parser_skeleton import ParseError, parse_record160_array, parse_record180_array


PROPERTY_HASH_RE = re.compile(
    r"<(?P<tag>main-model|arm-model|arrow-model|model-main|model-arm|model)>\s+"
    r"(?P<hash>[0-9a-f]{64})",
    re.IGNORECASE,
)


def _u64le(data: bytes, off: int) -> int:
    return int.from_bytes(data[off:off + 8], "little")


def _ascii_ratio(data: bytes) -> float:
    if not data:
        return 1.0
    printable = sum(0x20 <= b < 0x7F or b in (0x09, 0x0A, 0x0D) for b in data)
    return printable / len(data)


def _format_candidate_line(rank: int, cand: CandidateResult) -> str:
    trailer = "none"
    if cand.inner_trailer_xor is not None:
        trailer = f"0x{cand.inner_trailer_xor:016x}"
    return (
        f"[{rank}] score={cand.score} key_len=0x{cand.key_len:x} "
        f"sel_a=0x{cand.sel_a:02x} sel_b={cand.sel_b} rounds={cand.rounds} "
        f"profile={cand.profile.derivation_mode}/{cand.profile.state_layout}/ctr{cand.profile.counter0} "
        f"header=off:0x{cand.header_offset:x} d0:0x{cand.header_dword0:08x} d1:{cand.header_dword1} "
        f"inner_trailer_xor={trailer}"
    )


def _is_validated_inner_plaintext(cand: CandidateResult) -> bool:
    return (
        cand.header_offset == 0
        and cand.header_dword0 == 1
        and 1 <= cand.header_dword1 <= 31
        and cand.inner_trailer_xor == 0
    )


def _format_v3_candidate_line(rank: int, cand: V3ExactCandidate) -> str:
    zstd = (
        f"frame:{int(cand.section_tag == 0xFD2FB528)}"
        f"/skip:{int((cand.section_tag & 0xFFFFFFF0) == 0x184D2A50)}"
        f"/hdr:{int(cand.zstd_header_ok)}"
        f"/blk:{cand.zstd_block_type}"
        f"/size:{cand.zstd_block_size}"
        f"/wblk_ok:{int(cand.wrapper_block_ok)}"
        f"/wblk:{cand.wrapper_block_type}"
        f"/wsize:{cand.wrapper_block_size}"
        f"/wtx:{int(cand.wrapper_transcode_ok)}"
        f"/wzstd:{int(cand.wrapper_transcode_zstd_ok)}"
        f"/ok:{int(cand.zstd_decompress_ok)}"
    )
    return (
        f"[{rank}] score={cand.score} skip={cand.prelude_skip} off=0x{cand.section_offset:x} wrapper_tag=0x{cand.section_tag:08x} "
        f"rounds={cand.rounds} "
        f"profile={cand.profile.derivation_mode}/{cand.profile.state_layout}/ctr{cand.profile.counter0} "
        f"stage2={cand.second_stage} "
        f"small_dwords={cand.small_dword_count} ascii_head={cand.ascii_head_ratio:.3f} zstd={zstd}"
    )


def _print_record_probe(pt: bytes) -> None:
    if len(pt) < 17:
        print("inner_probe: plaintext too short for proven header + trailer")
        return

    flag_byte = pt[8]
    body = pt[9:-8]
    trailer = _u64le(pt, len(pt) - 8)
    print(f"inner_header.flag_byte: 0x{flag_byte:02x}")
    print(f"inner_body.length: 0x{len(body):x}")
    print(f"inner_trailer.value: 0x{trailer:016x}")

    if len(body) % 0x160 == 0:
        try:
            records160 = parse_record160_array(body)
            print(f"record160_probe.count: {len(records160)}")
        except ParseError as exc:
            print(f"record160_probe.error: {exc}")
    else:
        print("record160_probe: skipped (body length not multiple of 0x160)")

    if len(body) % 0x180 == 0:
        try:
            records180 = parse_record180_array(body)
            print(f"record180_probe.count: {len(records180)}")
        except ParseError as exc:
            print(f"record180_probe.error: {exc}")
    else:
        print("record180_probe: skipped (body length not multiple of 0x180)")


def _sanitize_name(name: str) -> str:
    out = []
    for ch in name:
        if ch.isalnum() or ch in ("-", "_", "."):
            out.append(ch)
        else:
            out.append("_")
    return "".join(out) or "entry"


def _print_outer_summary(path: Path, show_property: bool, dump_chunks: bool) -> None:
    data = path.read_bytes()
    if not data.startswith(MAGIC_PREFIX):
        print("outer_container: not a BOM+YSGP file")
        return

    scan = scan_file(path, dump=dump_chunks)
    layout = parse_outer_v3_layout(path)

    print("outer_container: headered_v3")
    print(f"property_end: 0x{scan.property_end:08x}")
    print(f"outer_separator_offset: 0x{layout.separator_offset:08x}")
    print(f"outer_version_offset: 0x{layout.version_offset:08x}")
    print(f"outer_version_value: {layout.version_value}")
    print(
        "encoded_plus_key_offset: "
        f"0x{layout.encoded_plus_key_and_trailer_offset:08x}"
    )
    print(f"encoded_plus_key_length: 0x{layout.encoded_plus_key_len:x}")
    print(f"outer_trailing_hash_offset: 0x{layout.trailing_hash_offset:08x}")
    print(f"outer_trailing_hash_verified: {layout.trailer_hash_verified}")
    property_hashes = list(PROPERTY_HASH_RE.finditer(scan.property_text))
    if property_hashes:
        print(f"property_asset_hashes: {len(property_hashes)}")
        for match in property_hashes:
            print(
                f"property_asset_hash.{match.group('tag')}: "
                f"{match.group('hash')}"
            )
    if show_property:
        print("property_block_begin")
        print(scan.property_text.rstrip("\n"))
        print("property_block_end")
    print(f"candidate_chunks: {len(scan.chunks)}")
    for idx, chunk in enumerate(scan.chunks):
        print(
            f"chunk[{idx}]: start=0x{chunk.start:08x} end=0x{chunk.end:08x} "
            f"length=0x{chunk.length:x} ascii_ratio={chunk.ascii_ratio:.4f} "
            f"entropy={chunk.entropy:.4f}"
        )
        print(f"chunk[{idx}].first64: {chunk.first64_hex}")
        if dump_chunks:
            print(f"chunk[{idx}].dump: {chunk.dump_path}")


def _process_compact_v2(path: Path, probe_compact: bool, dump_entries: bool, compact_dump_top: int) -> None:
    container = parse_compact_v2_file(path)
    print("outer_container: compact_v2")
    print(f"compact_v2.version_be: {container.version_be}")
    print(f"compact_v2.header_md5_16: {container.header_md5_16.hex()}")
    print(f"compact_v2.header_md5_verified: {container.header_md5_verified}")
    print(f"compact_v2.entry_count: {len(container.entries)}")
    for entry, payload, key in extract_entry_payloads(container):
        name = entry.name_decoded if entry.name_decoded is not None else entry.name_b64.decode("ascii", "replace")
        print(
            f"entry[{entry.index}]: off=0x{entry.entry_offset:x} id={entry.entry_id.hex()} "
            f"name={name!r} payload_len=0x{entry.payload_len:x} key_len=0x{entry.key_len:x}"
        )
        print(
            f"entry[{entry.index}].payload_head32: {payload[:32].hex()} "
            f"payload_ascii_head={_ascii_ratio(payload[:0x80]):.3f}"
        )
        print(f"entry[{entry.index}].key_head32: {key[:32].hex()}")
        if dump_entries:
            base_name = _sanitize_name(name)
            payload_path = path.with_name(f"{path.stem}.entry_{entry.index:02d}.{base_name}.payload.bin")
            key_path = path.with_name(f"{path.stem}.entry_{entry.index:02d}.{base_name}.key.bin")
            payload_path.write_bytes(payload)
            key_path.write_bytes(key)
            print(f"entry[{entry.index}].payload_dump: {payload_path}")
            print(f"entry[{entry.index}].key_dump: {key_path}")
        if probe_compact:
            results = probe_compact_entry(name, entry.entry_id, payload, key, container.header_md5_16)
            if not results:
                print("compact_probe: skipped (key length unsupported)")
            else:
                for rank, result in enumerate(results[:3], 1):
                    print(
                        f"compact_probe[{rank}]: score={result.score:.3f} note={result.note or '-'} "
                        f"ascii={result.head_ascii_ratio:.3f} png={result.png_magic} "
                        f"jsonish={result.jsonish} hyp={result.hypothesis.label()}"
                    )
                    print(f"compact_probe[{rank}].head32: {result.plaintext[:32].hex()}")
                for rank, result in enumerate(results[:compact_dump_top], 1):
                    out = dump_probe_candidate(path, entry.index, name, rank, result)
                    print(f"compact_probe_dump[{rank}]: {out}")


def _process_one(
    path: Path,
    show_property: bool,
    dump_chunks: bool,
    key_lens: list[int],
    extra_rounds: list[int],
    top: int,
    dump_top: int,
    probe_records: bool,
    probe_compact: bool,
    dump_entries: bool,
    compact_dump_top: int,
) -> None:
    print(f"file: {path}")
    data = path.read_bytes()
    if data[:4] == b"YSGP" and len(data) >= 8 and int.from_bytes(data[4:8], "big") == 2:
        _process_compact_v2(
            path,
            probe_compact=probe_compact,
            dump_entries=dump_entries,
            compact_dump_top=compact_dump_top,
        )
        return
    if data.startswith(MAGIC_PREFIX):
        _print_outer_summary(path, show_property=show_property, dump_chunks=dump_chunks)
        try:
            exact = parse_v3_exact_input(path)
        except ValueError as exc:
            print(f"v3_exact_probe: skipped ({exc})")
            return

        print(f"v3_exact.ciphertext_offset: 0x{exact.encoded_offset:x}")
        print(f"v3_exact.ciphertext_length: 0x{len(exact.ciphertext):x}")
        print(f"v3_exact.key56_offset: 0x{exact.key56_offset:x}")
        print(f"v3_exact.key56_hash: 0x{exact.key_hash:016x}")
        print(f"v3_exact.sel_a: 0x{exact.sel_a:02x}")
        print(f"v3_exact.sel_b: {exact.sel_b}")

        v3_results = enumerate_v3_exact_candidates(exact, extra_rounds=extra_rounds)
        valid_v3 = [cand for cand in v3_results if is_valid_v3_stream_candidate(cand)]
        print(f"v3_stream_candidates: {len(v3_results)}")
        print(f"v3_stream_valid_frames: {len(valid_v3)}")
        if valid_v3:
            for idx, cand in enumerate(valid_v3[:top], 1):
                print(_format_v3_candidate_line(idx, cand))
        else:
            print("note: no v3 stream candidate reached a convincing post-skip compressed-wrapper stream")
            for idx, cand in enumerate(v3_results[:top], 1):
                print(_format_v3_candidate_line(idx, cand))

        dump_set = valid_v3 if valid_v3 else v3_results
        for idx, cand in enumerate(dump_set[:dump_top], 1):
            out_path = dump_v3_candidate(path, idx, cand)
            print(f"dumped_v3[{idx}]: {out_path}")
        return

    try:
        src = load_input(path)
    except ValueError as exc:
        print(f"decode_probe: skipped ({exc})")
        return
    results = enumerate_candidates(src, key_lens, extra_rounds)

    print(f"decode_probe.chunk_offset_in_file: 0x{src.chunk_offset_in_file:x}")
    print(f"decode_probe.chunk_length: 0x{len(src.chunk):x}")

    validated = [cand for cand in results if _is_validated_inner_plaintext(cand)]
    if validated:
        print(f"validated_candidates: {len(validated)}")
        for idx, cand in enumerate(validated[:top], 1):
            print(_format_candidate_line(idx, cand))
            if probe_records and idx == 1:
                _print_record_probe(cand.plaintext)
    else:
        print("validated_candidates: 0")
        print("note: no candidate satisfied the proven inner header + trailer checks")
        for idx, cand in enumerate(results[:top], 1):
            print(_format_candidate_line(idx, cand))

    dump_set = validated if validated else results
    for idx, cand in enumerate(dump_set[:dump_top], 1):
        out_path = dump_candidate(path, idx, cand)
        print(f"dumped[{idx}]: {out_path}")


def build_argparser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Best-effort YSM/YSGP parser that keeps outer framing, decode attempts, and record probes separate."
    )
    parser.add_argument("inputs", nargs="+", help="full .ysm/.ysgp files or carved v3 chunks")
    parser.add_argument(
        "--show-property",
        action="store_true",
        help="print the UTF-8 property block for full BOM+YSGP files",
    )
    parser.add_argument(
        "--dump-chunks",
        action="store_true",
        help="dump scanner candidate chunks beside full BOM+YSGP inputs",
    )
    parser.add_argument(
        "--key-lens",
        default="56,48,64,72,80,88,96",
        help="comma-separated candidate appended key-blob lengths to test",
    )
    parser.add_argument(
        "--extra-rounds",
        default="10,20,30",
        help="comma-separated fallback even round counts to test in addition to derived sel_b",
    )
    parser.add_argument(
        "--top",
        type=int,
        default=8,
        help="number of candidate rows to print",
    )
    parser.add_argument(
        "--dump-top",
        type=int,
        default=0,
        help="number of candidate plaintexts to dump beside each input",
    )
    parser.add_argument(
        "--probe-records",
        action="store_true",
        help="for a validated inner plaintext, probe the body as 0x160 and 0x180 arrays when lengths align exactly",
    )
    parser.add_argument(
        "--probe-compact",
        action="store_true",
        help="for compact v2 entries, run tentative ChaCha-family signature probes against each payload",
    )
    parser.add_argument(
        "--dump-entries",
        action="store_true",
        help="for compact v2 entries, dump each payload and key beside the input",
    )
    parser.add_argument(
        "--dump-compact-top",
        type=int,
        default=0,
        help="when --probe-compact is enabled, dump this many top compact probe plaintexts per entry",
    )
    return parser


def main() -> int:
    args = build_argparser().parse_args()
    key_lens = [int(part, 0) for part in args.key_lens.split(",") if part]
    extra_rounds = [int(part, 0) for part in args.extra_rounds.split(",") if part]
    for idx, input_path in enumerate(args.inputs):
        if idx:
            print()
        _process_one(
            path=Path(input_path),
            show_property=args.show_property,
            dump_chunks=args.dump_chunks,
            key_lens=key_lens,
            extra_rounds=extra_rounds,
            top=args.top,
            dump_top=args.dump_top,
            probe_records=args.probe_records,
            probe_compact=args.probe_compact,
            dump_entries=args.dump_entries,
            compact_dump_top=args.dump_compact_top,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
