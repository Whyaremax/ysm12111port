#@category YSM

from ghidra.app.decompiler import DecompInterface
from ghidra.program.model.address import Address
from ghidra.program.model.listing import Function
from ghidra.util.task import ConsoleTaskMonitor


def parse_addr(text):
    if text.startswith("0x") or text.startswith("0X"):
        text = text[2:]
    return toAddr(text)


def ensure_function(addr):
    func = getFunctionContaining(addr)
    if func is not None and func.getEntryPoint() == addr:
        return func
    func = getFunctionAt(addr)
    if func is not None:
        return func
    disassemble(addr)
    created = createFunction(addr, None)
    if created is None:
        created = getFunctionContaining(addr)
    return created


def decompile(func):
    ifc = DecompInterface()
    ifc.openProgram(currentProgram)
    res = ifc.decompileFunction(func, 60, ConsoleTaskMonitor())
    if not res.decompileCompleted():
        print("DECOMP_FAIL %s" % func.getEntryPoint())
        return
    print("===== DECOMPILE %s %s =====" % (func.getName(), func.getEntryPoint()))
    print(res.getDecompiledFunction().getC())


args = getScriptArgs()
for addr_text in args:
    addr = parse_addr(addr_text)
    func = ensure_function(addr)
    if func is None:
        print("NOFUNC %s" % addr_text)
        continue
    print("===== FUNC %s %s =====" % (func.getName(), func.getEntryPoint()))
    decompile(func)
