from __future__ import annotations

import argparse
import gzip
import json
import zlib
from dataclasses import dataclass
from pathlib import Path

from provider1_chacha_reference import Provider1State, chacha_xor_stream, hchacha20_like_32
from ysgp_compact_v2_parser import extract_entry_payloads, parse_compact_v2_file
from ysgp_end_to_end_extractor import _xor_stream_variant


PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
ZIP_MAGIC = b"PK\x03\x04"
GZIP_MAGIC = b"\x1f\x8b"


def _u64le(data: bytes, off: int) -> int:
    return int.from_bytes(data[off:off + 8], "little")


def _u64be(data: bytes, off: int) -> int:
    return int.from_bytes(data[off:off + 8], "big")


def _ascii_ratio(data: bytes) -> float:
    if not data:
        return 1.0
    printable = sum(0x20 <= b < 0x7F or b in (0x09, 0x0A, 0x0D) for b in data)
    return printable / len(data)


def _json_like_bonus(head: bytes) -> float:
    bonus = 0.0
    stripped = head.lstrip()
    if stripped.startswith((b"{", b"[", b"\"", b"true", b"false", b"null")):
        bonus += 3.0
    for token in (b'"name"', b'"format_version"', b'"animations"', b'"resolution"', b'"elements"', b'"textures"'):
        if token in head:
            bonus += 0.75
    return bonus


def _extension_hint(name: str) -> str:
    lowered = name.lower()
    if lowered.endswith(".png"):
        return "png"
    if lowered.endswith(".json") or lowered.endswith(".bbmodel"):
        return "json"
    return "generic"


@dataclass(frozen=True)
class CompactHypothesis:
    derivation: str
    secondary16_source: str
    nonce64_source: str
    layout: str
    counter0: int
    rounds: int

    def label(self) -> str:
        return (
            f"{self.derivation}/sec={self.secondary16_source}/nonce={self.nonce64_source}/"
            f"layout={self.layout}/ctr0={self.counter0}/r={self.rounds}"
        )


@dataclass(frozen=True)
class CompactProbeResult:
    score: float
    hypothesis: CompactHypothesis
    head_ascii_ratio: float
    plaintext: bytes
    png_magic: bool
    zip_magic: bool
    gzip_magic: bool
    jsonish: bool
    note: str | None


def _secondary16_choices(entry_id: bytes, header_md5_16: bytes) -> dict[str, bytes]:
    return {
        "entry_id": entry_id,
        "header_md5_16": header_md5_16,
        "zero16": b"\x00" * 16,
    }


def _nonce64_choices(entry_id: bytes, header_md5_16: bytes) -> dict[str, int]:
    return {
        "zero64": 0,
        "entry_lo_le": _u64le(entry_id, 0),
        "entry_hi_le": _u64le(entry_id, 8),
        "entry_lo_be": _u64be(entry_id, 0),
        "entry_hi_be": _u64be(entry_id, 8),
        "hdr_lo_le": _u64le(header_md5_16, 0),
        "hdr_hi_le": _u64le(header_md5_16, 8),
        "hdr_lo_be": _u64be(header_md5_16, 0),
        "hdr_hi_be": _u64be(header_md5_16, 8),
    }


def _derive_key32(key32: bytes, secondary16: bytes, rounds: int, derivation: str) -> bytes:
    if derivation == "direct":
        return key32
    if derivation == "hchacha":
        return hchacha20_like_32(key32, secondary16, rounds)
    raise ValueError(f"unknown derivation {derivation}")


def _decrypt(payload: bytes, key32: bytes, hypothesis: CompactHypothesis, entry_id: bytes, header_md5_16: bytes) -> bytes:
    secondary16 = _secondary16_choices(entry_id, header_md5_16)[hypothesis.secondary16_source]
    nonce64 = _nonce64_choices(entry_id, header_md5_16)[hypothesis.nonce64_source]
    derived = _derive_key32(key32, secondary16, hypothesis.rounds, hypothesis.derivation)
    if hypothesis.layout == "ctr64_nonce64":
        state = Provider1State(
            key_or_subkey32=derived,
            counter64=hypothesis.counter0,
            secondary_qword64=nonce64,
            rounds=hypothesis.rounds,
        )
        return chacha_xor_stream(state, payload)
    return _xor_stream_variant(
        key_or_subkey32=derived,
        secondary_qword64=nonce64,
        rounds=hypothesis.rounds,
        src=payload,
        layout=hypothesis.layout,
        counter0=hypothesis.counter0,
    )


def _score_plaintext(name: str, plaintext: bytes) -> tuple[float, str | None]:
    hint = _extension_hint(name)
    head = plaintext[:0x100]
    score = _ascii_ratio(head)
    note = None

    if plaintext.startswith(PNG_MAGIC):
        score += 8.0
        note = "png_magic"
    if plaintext.startswith(ZIP_MAGIC):
        score += 6.0
        note = note or "zip_magic"
    if plaintext.startswith(GZIP_MAGIC):
        score += 5.0
        note = note or "gzip_magic"

    json_bonus = _json_like_bonus(head)
    score += json_bonus
    if json_bonus and note is None:
        note = "json_tokens"

    if hint == "png":
        if plaintext.startswith(PNG_MAGIC):
            score += 6.0
        else:
            score -= 1.0
    elif hint == "json":
        score += json_bonus
        try:
            json.loads(plaintext[: min(len(plaintext), 0x8000)].decode("utf-8"))
            score += 10.0
            note = "json_parse"
        except Exception:
            pass
    else:
        if _ascii_ratio(head) > 0.75:
            score += 1.0

    if plaintext.startswith(GZIP_MAGIC):
        try:
            inflated = gzip.decompress(plaintext[: min(len(plaintext), 0x20000)])
            score += _json_like_bonus(inflated[:0x100]) + 1.5
            note = note or "gzip_inflated"
        except Exception:
            pass

    for wbits in (zlib.MAX_WBITS, -zlib.MAX_WBITS):
        try:
            inflated = zlib.decompress(plaintext[: min(len(plaintext), 0x20000)], wbits)
            bonus = _json_like_bonus(inflated[:0x100])
            if bonus:
                score += bonus + 1.0
                note = note or "zlib_inflated"
                break
        except Exception:
            continue

    return score, note


def enumerate_compact_hypotheses(rounds_set: tuple[int, ...] = (10, 20, 30)) -> list[CompactHypothesis]:
    derivations = ("direct", "hchacha")
    secondary_sources = ("entry_id", "header_md5_16", "zero16")
    nonce_sources = (
        "zero64",
        "entry_lo_le",
        "entry_hi_le",
        "hdr_lo_le",
        "hdr_hi_le",
        "entry_lo_be",
        "entry_hi_be",
        "hdr_lo_be",
        "hdr_hi_be",
    )
    layouts = (
        "ctr64_nonce64",
        "nonce64_ctr64",
        "ctr32_z_nonce64",
        "z_ctr32_nonce64",
        "nonce64_ctr32_z",
        "nonce64_z_ctr32",
    )
    out: list[CompactHypothesis] = []
    for derivation in derivations:
        for secondary in secondary_sources:
            if derivation == "direct" and secondary != "zero16":
                continue
            for nonce in nonce_sources:
                for layout in layouts:
                    for counter0 in (0, 1):
                        for rounds in rounds_set:
                            out.append(
                                CompactHypothesis(
                                    derivation=derivation,
                                    secondary16_source=secondary,
                                    nonce64_source=nonce,
                                    layout=layout,
                                    counter0=counter0,
                                    rounds=rounds,
                                )
                            )
    return out


def probe_compact_entry(name: str, entry_id: bytes, payload: bytes, key: bytes, header_md5_16: bytes) -> list[CompactProbeResult]:
    if len(key) != 0x20:
        return []
    preview_len = min(len(payload), 0x1000)
    scored: list[tuple[float, CompactHypothesis, float, bool, bool, bool, bool, str | None]] = []
    for hypothesis in enumerate_compact_hypotheses():
        preview = _decrypt(payload[:preview_len], key, hypothesis, entry_id, header_md5_16)
        score, note = _score_plaintext(name, preview)
        head = preview[:0x100]
        scored.append(
            (
                score,
                hypothesis,
                _ascii_ratio(head),
                preview.startswith(PNG_MAGIC),
                preview.startswith(ZIP_MAGIC),
                preview.startswith(GZIP_MAGIC),
                head.lstrip().startswith((b"{", b"[", b"\"", b"true", b"false", b"null")),
                note,
            )
        )
    scored.sort(key=lambda row: row[0], reverse=True)

    results: list[CompactProbeResult] = []
    for score, hypothesis, head_ascii_ratio, png_magic, zip_magic, gzip_magic, jsonish, note in scored[:24]:
        pt = _decrypt(payload, key, hypothesis, entry_id, header_md5_16)
        results.append(
            CompactProbeResult(
                score=score,
                hypothesis=hypothesis,
                head_ascii_ratio=head_ascii_ratio,
                plaintext=pt,
                png_magic=png_magic,
                zip_magic=zip_magic,
                gzip_magic=gzip_magic,
                jsonish=jsonish,
                note=note,
            )
        )
    results.sort(key=lambda row: row.score, reverse=True)
    return results


def dump_probe_candidate(base: Path, entry_index: int, name: str, rank: int, result: CompactProbeResult) -> Path:
    safe = "".join(ch if ch.isalnum() or ch in ("-", "_", ".") else "_" for ch in name) or "entry"
    out = base.with_name(
        f"{base.stem}.entry_{entry_index:02d}.{safe}.probe_{rank:02d}."
        f"{result.hypothesis.derivation}.{result.hypothesis.secondary16_source}."
        f"{result.hypothesis.nonce64_source}.{result.hypothesis.layout}.ctr{result.hypothesis.counter0}."
        f"r{result.hypothesis.rounds}.bin"
    )
    out.write_bytes(result.plaintext)
    return out


def build_argparser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Guided compact-v2 payload probe over constrained ChaCha-family state hypotheses."
    )
    parser.add_argument("input")
    parser.add_argument("--entry", type=int, default=None, help="probe only one entry index")
    parser.add_argument("--top", type=int, default=5)
    parser.add_argument("--dump-top", type=int, default=0)
    return parser


def main() -> int:
    args = build_argparser().parse_args()
    container = parse_compact_v2_file(Path(args.input))
    for entry, payload, key in extract_entry_payloads(container):
        if args.entry is not None and entry.index != args.entry:
            continue
        name = entry.name_decoded if entry.name_decoded is not None else entry.name_b64.decode("ascii", "replace")
        results = probe_compact_entry(name, entry.entry_id, payload, key, container.header_md5_16)
        print(f"entry[{entry.index}] {name!r} top={min(args.top, len(results))}")
        for rank, result in enumerate(results[:args.top], 1):
            print(
                f"[{rank}] score={result.score:.3f} note={result.note or '-'} "
                f"ascii={result.head_ascii_ratio:.3f} png={result.png_magic} jsonish={result.jsonish} "
                f"hyp={result.hypothesis.label()}"
            )
            print(f"    head32={result.plaintext[:32].hex()}")
        for rank, result in enumerate(results[:args.dump_top], 1):
            out = dump_probe_candidate(Path(args.input), entry.index, name, rank, result)
            print(f"dumped[{rank}]={out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
