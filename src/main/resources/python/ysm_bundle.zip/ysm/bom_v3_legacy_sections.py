from __future__ import annotations

import argparse
import binascii
import hashlib
import itertools
import json
import math
import re
import struct
import zlib
from dataclasses import dataclass
from pathlib import Path

try:
    from PIL import Image
except Exception:  # pragma: no cover - optional dependency
    Image = None

from bom_v3_end_to_end_parser import decode_bom_v3
from bom_v3_payload_assets import (
    _canonical_animation_stub_name,
    _canonical_model_stub_name,
    _parse_animation_headers,
    _read_property_name,
    _read_property_format,
    _sanitize_name,
    build_animation_decompile_stub,
    build_model_decompile_stub,
    parse_property_assets,
)
from ysgp_container_scanner import scan_file


HEX_HASH_RE = re.compile(rb"[0-9a-f]{64}")
SECTION_TAGS = (b"\x09\x00\x00\x00", b"\x0f\x00\x00\x00", b"\x1f\x00\x00\x00")
ANIM_HINTS = (
    b"query.",
    b"ysm.head_",
    b"swing_hand",
    b"reload",
    b"elytra_fly",
    b"carryon",
    b"attack",
    b"walk",
    b"idle",
    b"extra",
)
MODEL_HINTS = (
    b"geometry.unknown",
    b"MRoot",
    b"Root",
    b"AllBody",
    b"LeftArm",
    b"RightArm",
    b"LeftForeArm",
    b"RightForeArm",
    b"Head",
    b"bow",
)
LEGACY_SIGNATURES: dict[str, tuple[str, ...]] = {
    "main_animation": ("gui", "idle", "jump", "boat", "parallel0", "parallel1", "sneaking", "swim", "climb", "climbing"),
    "extra_animation": ("extra0", "extra1", "extra2", "extra3", "extra4", "extra5", "extra6", "extra7"),
    "tac_animation": ("tac", "reload", "rpg", "pistol", "ak47", "g17", "rifle", "bowL1", "bowR1", "aim"),
    "carryon_animation": ("carryon", "swing_hand", "use_mainhand", "use_offhand"),
    "arrow_animation": ("Board", "Board2", "Bowknot", "Brand", "LeftPl", "RightPl", "UpPl", "DownPl", "ARROW"),
}

_FORMAT9_MAIN_MODEL_EXCLUDE_NAMES = {
    "Board",
    "Board2",
    "Bowknot",
    "Bowknot2",
    "Bowknot3",
    "Bowknot4",
    "Bowknot5",
    "Brand",
    "DownPl",
    "LeftPl",
    "Other",
    "RightPl",
    "Sakura",
    "UpPl",
    "attacked",
    "boat",
    "climb",
    "climbing",
    "death",
    "geometry.unknown",
    "ysm.head_yaw",
}

_FORMAT9_ARM_MODEL_KEEP_NAMES = {
    "Arm",
    "LeftArm",
    "LeftForeArm",
    "LeftHand",
    "LeftHandLocator",
    "RightArm",
    "RightForeArm",
    "RightHand",
    "RightHandLocator",
}

_FORMAT9_ARROW_MODEL_EXCLUDE_NAMES = {
    "AllBody",
    "AllBody2",
    "AllHead",
    "AllHead2",
    "Head",
    "Head2",
    "UpBody",
    "UpperBody",
    "LeftArm",
    "LeftFoot",
    "LeftForeArm",
    "LeftLeg",
    "LeftLowerLeg",
    "RightArm",
    "RightFoot",
    "RightForeArm",
    "RightLeg",
    "RightLowerLeg",
    "LongHair",
    "LongHair2",
    "LongLeftHair",
    "LongRightHair",
    "MAllbody",
    "MAllBody",
    "MHead",
    "MLongHair",
    "MTail",
    "Tail",
    "Tail2",
    "Tail3",
    "Tail4",
    "elytra_fly",
    "fly",
    "weixiao",
}

_FORMAT9_ARROW_MODEL_KEEP_NAMES = {
    "Root",
    "UpPl",
    "DownPl",
    "LeftPl",
    "RightPl",
    "Other",
    "Bowknot",
    "Bowknot2",
    "Bowknot3",
    "Bowknot4",
    "Bowknot5",
    "Board",
    "Board2",
    "Brand",
    "Sakura",
}

_FORMAT9_CONTAINER_BONE_NAMES = {
    "AllBody",
    "Arm",
    "DownBody",
    "Ear",
    "EyeBrow",
    "Eyelid",
    "Eyes",
    "Leg",
    "Mouth",
    "gui",
}

_PLAUSIBLE_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.-]{1,31}$")


def _canonical_legacy_json_name(asset_name: str, kind: str) -> str | None:
    if kind == "model":
        mapping = {
            "main_model": "main.json",
            "arm_model": "arm.json",
            "arrow_model": "arrow.json",
        }
        return mapping.get(asset_name)
    if kind == "animation":
        mapping = {
            "main_animation": "main.animation.json",
            "arm_animation": "arm.animation.json",
            "extra_animation": "extra.animation.json",
            "tac_animation": "tac.animation.json",
            "carryon_animation": "carryon.animation.json",
            "arrow_animation": "arrow.animation.json",
            "parcool_animation": "parcool.animation.json",
            "swem_animation": "swem.animation.json",
        }
        return mapping.get(asset_name)
    return None


@dataclass(frozen=True)
class LegacySection:
    start: int
    end: int
    size: int
    tag: int
    kind_guess: str
    names: tuple[str, ...]
    asset_guess: str | None
    sha256: str


@dataclass(frozen=True)
class LegacyDirectoryEntry:
    offset: int
    control: tuple[int, ...]
    name: str
    hash_hex: str
    property_match: str | None


@dataclass(frozen=True)
class LegacyScanResult:
    path: Path
    codec_format: int | None
    decoded_len: int
    tail_start: int
    directory_start: int
    directory_prefix: str
    directory_entries: tuple[LegacyDirectoryEntry, ...]
    sections: tuple[LegacySection, ...]


@dataclass(frozen=True)
class LegacyTextureExport:
    asset_name: str
    label: str
    width: int
    height: int
    offset: int
    raw_len: int
    png_file: str
    sha256: str


@dataclass(frozen=True)
class LegacyModelBoneInfo:
    name: str
    parent: str | None
    pivot: tuple[float, float, float] | None
    cube_count_guess: int | None = None
    wrapper_name: str | None = None
    uv_norm_hints: tuple[float, ...] = ()


_LEGACY_BONE_NAME_HINTS = (
    "Root",
    "Body",
    "Head",
    "Hair",
    "Arm",
    "Leg",
    "Hand",
    "Foot",
    "Eye",
    "Brow",
    "Ear",
    "Tail",
    "Wing",
    "Ribbon",
    "Skirt",
    "Sleeve",
    "Clothes",
)

_LEGACY_WRAPPER_NAME_RE = re.compile(r"^(?:M[0-9]+|[A-Z][A-Za-z0-9_-]*M[0-9]?)$")


def _entropy(buf: bytes) -> float:
    if not buf:
        return 0.0
    counts = [0] * 256
    for b in buf:
        counts[b] += 1
    total = len(buf)
    ent = 0.0
    for c in counts:
        if c:
            p = c / total
            ent -= p * math.log2(p)
    return ent


def _ascii_ratio(buf: bytes) -> float:
    if not buf:
        return 0.0
    printable = sum(1 for b in buf if 32 <= b < 127 or b in (9, 10, 13))
    return printable / len(buf)


def _extract_names(buf: bytes, limit: int = 16) -> tuple[str, ...]:
    names: list[str] = []
    seen: set[str] = set()
    for m in re.finditer(rb"[A-Za-z_][A-Za-z0-9_.-]{2,}", buf):
        s = m.group().decode("ascii", "replace")
        if all(ch in "0123456789abcdef" for ch in s.lower()):
            continue
        if s in seen:
            continue
        seen.add(s)
        names.append(s)
        if len(names) >= limit:
            break
    return tuple(names)


def _classify_section(buf: bytes, names: tuple[str, ...]) -> str:
    anim_headers = _parse_animation_headers(buf)
    if anim_headers:
        first_off = int(anim_headers[0]["offset"])
        strong_model_names = {"MRoot", "Root", "AllBody", "LeftArm", "RightArm", "Head", "UpperBody"}
        strong_model_count = sum(1 for name in names if name in strong_model_names)
        if first_off < min(0x10000, max(0x400, len(buf) // 3)):
            if len(anim_headers) >= 3:
                return "animation"
            if len(anim_headers) >= 2 and strong_model_count < 3:
                return "animation"
    ogg_off = buf.find(b"OggS")
    if ogg_off >= 0:
        return "audio"
    anim_score = sum(1 for hint in ANIM_HINTS if hint in buf)
    model_score = sum(1 for hint in MODEL_HINTS if hint in buf)
    if anim_score >= 4 and anim_score >= model_score - 1:
        return "animation"
    strong_model_names = {"MRoot", "Root", "AllBody", "LeftArm", "RightArm", "Head", "UpperBody"}
    if sum(1 for name in names if name in strong_model_names) >= 3:
        return "model"
    if model_score >= max(3, anim_score + 2):
        return "model"
    if anim_score >= max(2, model_score):
        return "animation"
    if _ascii_ratio(buf[: min(len(buf), 0x2000)]) < 0.15 and _entropy(buf[: min(len(buf), 0x8000)]) > 7.2:
        return "texture_or_binary"
    if any(name in names for name in ("Root", "AllBody", "LeftArm", "RightArm")):
        return "model"
    return "unknown"


def _property_kind(tag: str) -> str:
    tag = tag.lower()
    if tag.startswith("sound_"):
        return "audio"
    if "animation" in tag:
        return "animation"
    if "model" in tag or tag == "model":
        return "model"
    if "texture" in tag:
        return "texture_or_binary"
    return "unknown"


def _legacy_signature_scores(buf: bytes) -> dict[str, int]:
    return {
        asset_name: sum(1 for tok in tokens if tok.encode("ascii") in buf)
        for asset_name, tokens in LEGACY_SIGNATURES.items()
    }


def _build_legacy_animation_signature_stub(
    asset_name: str, section_sha256: str, names: tuple[str, ...], signature_scores: dict[str, int]
) -> dict[str, object]:
    token_names = list(LEGACY_SIGNATURES.get(asset_name, ()))
    guessed_bones: list[str] = []
    seen: set[str] = set()
    token_set = set(token_names)
    for name in names:
        if name in token_set:
            continue
        if name in seen:
            continue
        seen.add(name)
        guessed_bones.append(name)
        if len(guessed_bones) >= 24:
            break
    animations = {
        clip_name: {
            "__recovered_from": "legacy_signature_tokens",
            "__bone_names_guess": guessed_bones,
            "bones": {},
        }
        for clip_name in token_names
    }
    return {
        "format_version": "1.8.0",
        "__compiled_decompile": {
            "status": "signature_only",
            "asset_name": asset_name,
            "section_sha256": section_sha256,
            "clip_count_guess": len(token_names),
            "bone_name_count_guess": len(guessed_bones),
            "signature_score": int(signature_scores.get(asset_name, 0)),
            "notes": [
                "Recovered from compiled legacy YSM animation section.",
                "Clip names are inferred from embedded signature tokens.",
                "Durations, loop modes, and keyframe channels are not reconstructed yet.",
                "Bone lists are guessed from embedded strings.",
            ],
        },
        "animations": animations,
    }


def _strip_private_fields(value: object) -> object:
    if isinstance(value, dict):
        out: dict[str, object] = {}
        for key, item in value.items():
            if isinstance(key, str) and key.startswith("__"):
                continue
            out[key] = _strip_private_fields(item)
        return out
    if isinstance(value, list):
        return [_strip_private_fields(item) for item in value]
    return value


def _plausible_legacy_name(text: str) -> bool:
    return _PLAUSIBLE_NAME_RE.fullmatch(text) is not None


def _iter_len_prefixed_names(section: bytes) -> list[tuple[int, str]]:
    out: list[tuple[int, str]] = []
    for off in range(len(section) - 2):
        n = section[off]
        end = off + 1 + n
        if not (1 <= n <= 32 and end < len(section)):
            continue
        if section[end] != 0:
            continue
        try:
            text = section[off + 1:end].decode("ascii")
        except UnicodeDecodeError:
            continue
        if _plausible_legacy_name(text):
            out.append((off, text))
    return out


def _read_legacy_pivot(section: bytes, name_off: int, name: str) -> tuple[float, float, float] | None:
    end = name_off + 1 + len(name) + 1
    best: tuple[float, float, float] | None = None
    best_score = -1.0
    for shift in (4, 0, 8, 12):
        if end + shift + 12 > len(section):
            continue
        vals = struct.unpack_from("<3f", section, end + shift)
        if not all(math.isfinite(v) and abs(v) <= 2048.0 for v in vals):
            continue
        score = 0.0
        if shift == 4:
            score += 0.4
        if any(abs(v) > 0.001 for v in vals):
            score += 0.5
        for v in vals:
            if abs(v) <= 512.0:
                score += 1.0
            if abs(v - round(v, 3)) < 1e-5:
                score += 0.15
        rounded = tuple(0.0 if abs(v) < 1e-6 else round(v, 5) for v in vals)
        if score > best_score:
            best_score = score
            best = rounded
    return best


def _find_legacy_wrapper_payload(section: bytes, visible_name: str) -> tuple[str, int, int, bytes] | None:
    wrapper_name = "M" + visible_name
    first_pat = bytes([len(wrapper_name)]) + wrapper_name.encode("ascii") + b"\x00"
    first = section.find(first_pat)
    if first < 0:
        return None

    second_pat = b"\x00" + bytes([len(wrapper_name)]) + wrapper_name.encode("ascii")
    second = section.find(second_pat, first + len(first_pat))
    if second < 0:
        second = section.find(bytes([len(wrapper_name)]) + wrapper_name.encode("ascii"), first + len(first_pat))
        if second < 0:
            return None
        payload_off = second + 1 + len(wrapper_name)
    else:
        payload_off = second + 1 + 1 + len(wrapper_name)

    if payload_off < len(section) and section[payload_off] == 0:
        payload_off += 1

    end_pat = bytes([len(visible_name)]) + visible_name.encode("ascii") + b"\x00"
    block_end = section.find(end_pat, payload_off)
    if block_end < 0:
        return None
    if payload_off + 2 > block_end:
        return None

    count = section[payload_off]
    kind = section[payload_off + 1]
    payload = section[payload_off + 2:block_end]
    return wrapper_name, count, kind, payload


def _find_legacy_visible_payload_same_name(
    section: bytes,
    visible_name: str,
) -> tuple[str, int, int, bytes] | None:
    pat = bytes([len(visible_name)]) + visible_name.encode("ascii") + b"\x00"
    pat_no_nul = bytes([len(visible_name)]) + visible_name.encode("ascii")
    start = 0
    best: tuple[str, int, int, bytes] | None = None
    while True:
        first = section.find(pat, start)
        if first < 0:
            break
        second = section.find(pat, first + len(pat))
        if second < 0:
            second = section.find(pat_no_nul, first + len(pat))
            if second < 0:
                start = first + 1
                continue
            payload_off = second + len(pat_no_nul)
        else:
            payload_off = second + len(pat)
        if payload_off < len(section) and section[payload_off] == 0:
            payload_off += 1
        if payload_off + 2 > len(section):
            start = first + 1
            continue
        count = section[payload_off]
        kind = section[payload_off + 1]
        block_end = len(section)
        search_end = min(len(section) - 2, payload_off + 0x4000)
        for off in range(payload_off + 2, search_end):
            ln = section[off]
            end = off + 1 + ln
            if not (1 <= ln <= 32 and end < len(section) and section[end] == 0):
                continue
            try:
                text = section[off + 1:end].decode("ascii")
            except UnicodeDecodeError:
                continue
            if _plausible_legacy_name(text):
                block_end = off
                break
        payload = section[payload_off + 2:block_end]
        candidate = (visible_name, count, kind, payload)
        if kind == 6:
            return candidate
        if best is None:
            best = candidate
        start = first + 1
    return best


def _find_legacy_single_visible_container_slice(
    section: bytes,
    visible_name: str,
    *,
    window: int = 0x800,
) -> bytes | None:
    pat = bytes([len(visible_name)]) + visible_name.encode("ascii") + b"\x00"
    off = section.find(pat)
    if off < 0:
        return None
    start = off + len(pat)
    if start >= len(section):
        return None
    end = min(len(section), start + window)
    return section[start:end]


def _find_legacy_best_named_payload(
    section: bytes,
    visible_name: str,
    inline_payload: bytes | None = None,
) -> tuple[str, int, int, bytes] | None:
    best: tuple[str, int, int, bytes] | None = None
    if inline_payload is not None:
        best = (visible_name, 0, 0, inline_payload)
    for candidate in (
        _find_legacy_visible_payload_same_name(section, visible_name),
        _find_legacy_wrapper_payload_by_wrapper(section, visible_name),
        _find_legacy_wrapper_payload(section, visible_name),
    ):
        if candidate is None:
            continue
        if best is None or len(candidate[3]) > len(best[3]):
            best = candidate
    return best


def _find_legacy_wrapper_payload_by_wrapper(
    section: bytes,
    wrapper_name: str,
) -> tuple[str, int, int, bytes] | None:
    first_pat = bytes([len(wrapper_name)]) + wrapper_name.encode("ascii") + b"\x00"
    first = section.find(first_pat)
    if first < 0:
        return None
    second_pat = b"\x00" + bytes([len(wrapper_name)]) + wrapper_name.encode("ascii")
    second = section.find(second_pat, first + len(first_pat))
    if second < 0:
        second = section.find(bytes([len(wrapper_name)]) + wrapper_name.encode("ascii"), first + len(first_pat))
        if second < 0:
            return None
        payload_off = second + 1 + len(wrapper_name)
    else:
        payload_off = second + 1 + 1 + len(wrapper_name)
    if payload_off < len(section) and section[payload_off] == 0:
        payload_off += 1
    if payload_off + 2 > len(section):
        return None
    count = section[payload_off]
    kind = section[payload_off + 1]
    block_end = len(section)
    search_end = min(len(section) - 2, payload_off + 0x4000)
    for off in range(payload_off + 2, search_end):
        ln = section[off]
        end = off + 1 + ln
        if not (1 <= ln <= 32 and end < len(section) and section[end] == 0):
            continue
        try:
            text = section[off + 1:end].decode("ascii")
        except UnicodeDecodeError:
            continue
        if _plausible_legacy_name(text):
            block_end = off
            break
    payload = section[payload_off + 2:block_end]
    return wrapper_name, count, kind, payload


def _unwrap_legacy_nested_wrapper_payload(
    payload: bytes,
) -> tuple[str, int, int, bytes] | None:
    search_end = min(len(payload) - 4, 128)
    best: tuple[str, int, int, bytes] | None = None
    for off in range(search_end):
        ln = payload[off]
        if not (1 <= ln <= 16 and off + 1 + ln + 2 <= len(payload)):
            continue
        raw_name = payload[off + 1 : off + 1 + ln]
        if not all(32 <= c < 127 for c in raw_name):
            continue
        try:
            name = raw_name.decode("ascii")
        except UnicodeDecodeError:
            continue
        j = off + 1 + ln
        while j < len(payload) and payload[j] == 0:
            j += 1
        if j + 2 > len(payload):
            continue
        count = payload[j]
        kind = payload[j + 1]
        if count <= 0 or kind <= 0:
            continue
        nested = payload[j + 2 :]
        if len(nested) < 92:
            continue
        candidate = (name, count, kind, nested)
        if kind == 6 and _LEGACY_WRAPPER_NAME_RE.fullmatch(name):
            return candidate
        if best is None and kind == 6:
            best = candidate
        elif best is None and _LEGACY_WRAPPER_NAME_RE.fullmatch(name):
            best = candidate
    return best


def _unwrap_legacy_nested_visible_payload(
    payload: bytes,
    *,
    depth: int = 0,
) -> tuple[str, int, int, bytes] | None:
    if depth >= 2:
        return None
    best: tuple[str, int, int, bytes] | None = None
    for off in range(0, min(len(payload) - 4, 256)):
        ln = payload[off]
        if not (1 <= ln <= 24 and off + 1 + ln + 2 <= len(payload)):
            continue
        raw_name = payload[off + 1 : off + 1 + ln]
        if not all(32 <= c < 127 for c in raw_name):
            continue
        try:
            name = raw_name.decode("ascii")
        except UnicodeDecodeError:
            continue
        if not _plausible_legacy_name(name):
            continue
        pat = bytes([ln]) + raw_name
        second = payload.find(pat, off + 1 + ln)
        if second < 0:
            continue
        payload_off = second + len(pat)
        if payload_off < len(payload) and payload[payload_off] == 0:
            payload_off += 1
        if payload_off + 2 > len(payload):
            continue
        count = payload[payload_off]
        kind = payload[payload_off + 1]
        if count <= 0 or kind <= 0:
            continue
        block_end = len(payload)
        search_end = min(len(payload) - 2, payload_off + 0x4000)
        for idx in range(payload_off + 2, search_end):
            l2 = payload[idx]
            end = idx + 1 + l2
            if not (1 <= l2 <= 32 and end < len(payload)):
                continue
            raw2 = payload[idx + 1 : end]
            if not all(32 <= c < 127 for c in raw2):
                continue
            if payload[end] == 0 or (idx > off and raw2 != raw_name):
                block_end = idx
                break
        nested = payload[payload_off + 2 : block_end]
        candidate = (name, count, kind, nested)
        if kind == 6:
            return candidate
        if kind in (70, 72, 76, 77, 82):
            deeper = _unwrap_legacy_nested_visible_payload(nested, depth=depth + 1)
            if deeper is not None:
                return deeper
        if best is None:
            best = candidate
    return best


def _unwrap_legacy_inline_visible_payload(
    payload: bytes,
    *,
    depth: int = 0,
) -> tuple[str, int, int, bytes] | None:
    if depth >= 2:
        return None
    best: tuple[str, int, int, bytes] | None = None
    for off in range(0, min(len(payload) - 4, 256)):
        ln = payload[off]
        if not (1 <= ln <= 24 and off + 1 + ln + 2 <= len(payload)):
            continue
        raw_name = payload[off + 1 : off + 1 + ln]
        if not all(32 <= c < 127 for c in raw_name):
            continue
        try:
            name = raw_name.decode("ascii")
        except UnicodeDecodeError:
            continue
        if not _plausible_legacy_name(name):
            continue
        payload_off = off + 1 + ln
        while payload_off < len(payload) and payload[payload_off] == 0:
            payload_off += 1
        if payload_off + 2 > len(payload):
            continue
        count = payload[payload_off]
        kind = payload[payload_off + 1]
        if count <= 0 or kind <= 0:
            continue
        nested = payload[payload_off + 2 :]
        candidate = (name, count, kind, nested)
        if kind == 6:
            return candidate
        if kind in (69, 70, 72, 76, 77, 82):
            deeper = _unwrap_legacy_inline_visible_payload(nested, depth=depth + 1)
            if deeper is not None:
                return deeper
            deeper = _unwrap_legacy_nested_visible_payload(nested, depth=depth + 1)
            if deeper is not None:
                return deeper
        if best is None:
            best = candidate
    return best


def _decode_legacy_payload_cubes(
    payload: bytes,
    tex: tuple[int, int] | None,
    *,
    bone_name: str,
    bone_pivot: tuple[float, float, float] | None,
    preferred_count: int,
) -> list[dict[str, object]]:
    quad_cubes = _build_legacy_face_quad_cubes(payload, tex)
    if quad_cubes:
        quad_cubes = _filter_legacy_cubes(
            quad_cubes,
            preferred_count=max(1, preferred_count),
        )
        quad_cubes = _refine_legacy_bone_cubes(
            bone_name,
            bone_pivot,
            quad_cubes,
        )
        return quad_cubes[: max(1, preferred_count)]
    if preferred_count == 1:
        cube_guess = _build_legacy_direct_one_cube(payload, tex)
        if cube_guess is not None:
            return [cube_guess]
    return []


def _extract_uv_norm_hints(payload: bytes, limit: int = 24) -> tuple[float, ...]:
    vals: list[float] = []
    seen: set[float] = set()
    for off in range(0, len(payload) - 4, 4):
        f = struct.unpack_from("<f", payload, off)[0]
        if not math.isfinite(f):
            continue
        if not (-2.0 <= f <= 2.0):
            continue
        snapped = round(f * 256.0) / 256.0
        if abs(f - snapped) > 0.002:
            continue
        snapped = round(snapped, 6)
        if snapped in seen:
            continue
        seen.add(snapped)
        vals.append(snapped)
        if len(vals) >= limit:
            break
    return tuple(vals)


def _extract_legacy_direct_cube_records(
    payload: bytes,
    tex_size: tuple[int, int] | None,
) -> list[tuple[tuple[float, float, float], tuple[int, int]]]:
    if tex_size is None:
        return []
    tex_w, tex_h = tex_size
    out: list[tuple[tuple[float, float, float], tuple[int, int]]] = []
    seen: set[tuple[tuple[float, float, float], tuple[int, int]]] = set()
    for start in range(20):
        for off in range(start, len(payload) - 20, 20):
            x, y, z, u, v = struct.unpack_from("<5f", payload, off)
            if not all(math.isfinite(n) for n in (x, y, z, u, v)):
                continue
            if max(abs(x), abs(y), abs(z)) > 4.0:
                continue
            ui = int(round(u * tex_w))
            vi = int(round(v * tex_h))
            if abs((u * tex_w) - ui) > 0.05 or abs((v * tex_h) - vi) > 0.05:
                continue
            if not (0 <= ui <= tex_w and 0 <= vi <= tex_h):
                continue
            pos = (
                round(x * 16.0, 5),
                round(y * 16.0, 5),
                round(z * 16.0, 5),
            )
            rec = (pos, (ui, vi))
            if rec not in seen:
                seen.add(rec)
                out.append(rec)
    return out


def _normal_to_face(nx: float, ny: float, nz: float) -> str | None:
    if abs(abs(nx) - 1.0) < 1e-3 and abs(ny) < 1e-3 and abs(nz) < 1e-3:
        return "east" if nx > 0 else "west"
    if abs(abs(ny) - 1.0) < 1e-3 and abs(nx) < 1e-3 and abs(nz) < 1e-3:
        return "up" if ny > 0 else "down"
    if abs(abs(nz) - 1.0) < 1e-3 and abs(nx) < 1e-3 and abs(ny) < 1e-3:
        return "south" if nz > 0 else "north"
    return None


def _normalize3(vec: tuple[float, float, float]) -> tuple[float, float, float] | None:
    norm = math.sqrt(vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2])
    if norm < 1e-6:
        return None
    return (vec[0] / norm, vec[1] / norm, vec[2] / norm)


def _cross3(a: tuple[float, float, float], b: tuple[float, float, float]) -> tuple[float, float, float]:
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def _dot3(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _basis_from_face_pairs(
    group: list[tuple[tuple[float, float, float], list[tuple[float, float, float, float, float]]]],
) -> tuple[tuple[float, float, float], tuple[float, float, float], tuple[float, float, float]] | None:
    axes: list[tuple[float, float, float]] = []
    for a, b in ((0, 1), (2, 3), (4, 5)):
        na = _normalize3(group[a][0])
        nb = _normalize3(group[b][0])
        if na is None or nb is None or _dot3(na, nb) > -0.85:
            return None
        axes.append(na)
    u, v, w_hint = axes
    if abs(_dot3(u, v)) > 0.35:
        return None
    w = _normalize3(_cross3(u, v))
    if w is None:
        return None
    if _dot3(w, w_hint) < 0:
        w = (-w[0], -w[1], -w[2])
    v = _normalize3(_cross3(w, u))
    if v is None:
        return None
    return u, v, w


def _euler_deg_from_basis(
    u: tuple[float, float, float],
    v: tuple[float, float, float],
    w: tuple[float, float, float],
) -> tuple[float, float, float]:
    r00, r01, r02 = u[0], v[0], w[0]
    r10, r11, r12 = u[1], v[1], w[1]
    r20, r21, r22 = u[2], v[2], w[2]
    if abs(r20) < 0.999999:
        ry = math.asin(-r20)
        rx = math.atan2(r21, r22)
        rz = math.atan2(r10, r00)
    else:
        ry = math.pi / 2 if r20 <= -1 else -math.pi / 2
        rx = math.atan2(-r12, r11)
        rz = 0.0
    return (round(math.degrees(rx), 5), round(math.degrees(ry), 5), round(math.degrees(rz), 5))


def _parse_legacy_face_records(
    payload: bytes,
) -> list[tuple[tuple[float, float, float], list[tuple[float, float, float, float, float]]]]:
    quads: list[tuple[tuple[float, float, float], list[tuple[float, float, float, float, float]]]] = []
    off = 0
    while off + 92 <= len(payload):
        vals = struct.unpack_from("<23f", payload, off)
        normal = (vals[0], vals[1], vals[2])
        norm_len = math.sqrt(normal[0] * normal[0] + normal[1] * normal[1] + normal[2] * normal[2])
        if not (0.7 <= norm_len <= 1.3):
            break
        verts: list[tuple[float, float, float, float, float]] = []
        ok = True
        for i in range(4):
            x, y, z, u, v = vals[3 + i * 5 : 3 + (i + 1) * 5]
            if not all(math.isfinite(t) for t in (x, y, z, u, v)):
                ok = False
                break
            verts.append((x * 16.0, y * 16.0, z * 16.0, u, v))
        if not ok:
            break
        quads.append((normal, verts))
        off += 92
    return quads


def _iter_legacy_face_record_runs(
    payload: bytes,
    *,
    min_run: int = 6,
) -> list[list[tuple[tuple[float, float, float], list[tuple[float, float, float, float, float]]]]]:
    runs: list[list[tuple[tuple[float, float, float], list[tuple[float, float, float, float, float]]]]] = []
    seen: set[tuple[int, int]] = set()
    limit = len(payload) - 92
    for start in range(0, max(0, limit + 1), 4):
        if any(start >= a and start < b for a, b in seen):
            continue
        run = _parse_legacy_face_records(payload[start:])
        if len(run) < min_run:
            continue
        span = (start, start + len(run) * 92)
        seen.add(span)
        runs.append(run)
    runs.sort(key=len, reverse=True)
    return runs


def _build_legacy_face_quad_cubes(
    payload: bytes,
    tex_size: tuple[int, int] | None,
) -> list[dict[str, object]]:
    if tex_size is None:
        return []
    tex_w, tex_h = tex_size
    cubes: list[dict[str, object]] = []
    seen_keys: set[tuple[float, float, float, float, float, float]] = set()
    for quads in _iter_legacy_face_record_runs(payload, min_run=6):
        i = 0
        while i + 6 <= len(quads):
            group = quads[i : i + 6]
            if len(group) < 6:
                break
            # Prefer the common legacy pattern of 3 opposite face pairs.
            pair_dots = []
            for a, b in ((0, 1), (2, 3), (4, 5)):
                na = group[a][0]
                nb = group[b][0]
                pair_dots.append(na[0] * nb[0] + na[1] * nb[1] + na[2] * nb[2])
            if sum(1 for d in pair_dots if d < -0.85) < 2:
                i += 1
                continue

            face_map: dict[str, list[tuple[float, float, float, float, float]]] = {}
            for idx, (normal, verts) in enumerate(group):
                face = _normal_to_face(*normal)
                if face is None or face in face_map:
                    face = ("west", "east", "north", "south", "up", "down")[idx]
                face_map[face] = verts
            all_verts = [v for verts in face_map.values() for v in verts]
            basis = _basis_from_face_pairs(group)
            if basis is not None:
                u, v, w = basis
                proj_u = [_dot3((vert[0], vert[1], vert[2]), u) for vert in all_verts]
                proj_v = [_dot3((vert[0], vert[1], vert[2]), v) for vert in all_verts]
                proj_w = [_dot3((vert[0], vert[1], vert[2]), w) for vert in all_verts]
                min_u, max_u = min(proj_u), max(proj_u)
                min_v, max_v = min(proj_v), max(proj_v)
                min_w, max_w = min(proj_w), max(proj_w)
                size = [round(max_u - min_u, 5), round(max_v - min_v, 5), round(max_w - min_w, 5)]
                center_u = (min_u + max_u) * 0.5
                center_v = (min_v + max_v) * 0.5
                center_w = (min_w + max_w) * 0.5
                center = (
                    u[0] * center_u + v[0] * center_v + w[0] * center_w,
                    u[1] * center_u + v[1] * center_v + w[1] * center_w,
                    u[2] * center_u + v[2] * center_v + w[2] * center_w,
                )
                origin = [
                    round(center[0] - size[0] * 0.5, 5),
                    round(center[1] - size[1] * 0.5, 5),
                    round(center[2] - size[2] * 0.5, 5),
                ]
                pivot = [round(center[0], 5), round(center[1], 5), round(center[2], 5)]
                rotation = list(_euler_deg_from_basis(u, v, w))
            else:
                xs = [v[0] for v in all_verts]
                ys = [v[1] for v in all_verts]
                zs = [v[2] for v in all_verts]
                origin = [round(min(xs), 5), round(min(ys), 5), round(min(zs), 5)]
                size = [round(max(xs) - min(xs), 5), round(max(ys) - min(ys), 5), round(max(zs) - min(zs), 5)]
                pivot = None
                rotation = None
            if max(size) < 0.1 or min(size) < 0.01:
                i += 1
                continue
            key = tuple(round(v, 3) for v in (*origin, *size))
            if key in seen_keys:
                i += 6
                continue
            seen_keys.add(key)

            cube: dict[str, object] = {
                "origin": origin,
                "size": size,
                "uv": {},
            }
            if pivot is not None:
                cube["pivot"] = pivot
            if rotation is not None and any(abs(v) > 0.001 for v in rotation):
                cube["rotation"] = rotation
            uv_faces: dict[str, dict[str, list[int]]] = {}
            for face, verts in face_map.items():
                us = [v[3] * tex_w for v in verts]
                vs = [v[4] * tex_h for v in verts]
                min_u = int(round(min(us)))
                max_u = int(round(max(us)))
                min_v = int(round(min(vs)))
                max_v = int(round(max(vs)))
                width = max(1, max_u - min_u)
                height = max(1, max_v - min_v)
                if face == "down":
                    uv_faces[face] = {"uv": [min_u, max_v], "uv_size": [width, -height]}
                else:
                    uv_faces[face] = {"uv": [min_u, min_v], "uv_size": [width, height]}
            cube["uv"] = uv_faces
            cubes.append(cube)
            i += 6
    return cubes


def _legacy_cube_score(cube: dict[str, object]) -> float:
    size = cube.get("size", [0.0, 0.0, 0.0])
    if not isinstance(size, list) or len(size) != 3:
        return -1e9
    sx, sy, sz = (float(size[0]), float(size[1]), float(size[2]))
    max_dim = max(sx, sy, sz)
    min_dim = min(sx, sy, sz)
    volume = sx * sy * sz
    face_count = len(cube.get("uv", {}))
    score = face_count * 100.0
    score -= volume * 0.02
    score -= max(0.0, max_dim - 12.0) * 20.0
    if cube.get("rotation") is not None:
        score += 10.0
    if cube.get("pivot") is not None:
        score += 5.0
    if min_dim < 0.08:
        score -= 20.0
    return score


def _legacy_cube_center(cube: dict[str, object]) -> tuple[float, float, float] | None:
    origin = cube.get("origin")
    size = cube.get("size")
    if not isinstance(origin, list) or not isinstance(size, list):
        return None
    if len(origin) != 3 or len(size) != 3:
        return None
    return (
        float(origin[0]) + float(size[0]) * 0.5,
        float(origin[1]) + float(size[1]) * 0.5,
        float(origin[2]) + float(size[2]) * 0.5,
    )


def _filter_legacy_cubes(
    cubes: list[dict[str, object]],
    preferred_count: int = 1,
) -> list[dict[str, object]]:
    if not cubes:
        return cubes
    ranked = sorted(cubes, key=_legacy_cube_score, reverse=True)
    kept = [cube for cube in ranked if _legacy_cube_score(cube) >= 40.0]
    if not kept:
        kept = ranked[:1]
    target = min(max(1, preferred_count), 6)
    if len(kept) < target:
        for cube in ranked:
            if cube in kept:
                continue
            size = cube.get("size", [0.0, 0.0, 0.0])
            if not isinstance(size, list) or len(size) != 3:
                continue
            max_dim = max(float(size[0]), float(size[1]), float(size[2]))
            min_dim = min(float(size[0]), float(size[1]), float(size[2]))
            score = _legacy_cube_score(cube)
            if max_dim > 40.0 or min_dim < 0.05 or score < -220.0:
                continue
            kept.append(cube)
            if len(kept) >= target:
                break
    return kept


def _refine_legacy_bone_cubes(
    bone_name: str,
    bone_pivot: tuple[float, float, float] | None,
    cubes: list[dict[str, object]],
) -> list[dict[str, object]]:
    if not cubes or bone_pivot is None:
        return cubes
    if bone_name not in {"Head", "UpperBody"}:
        return cubes

    refined: list[dict[str, object]] = []
    for cube in cubes:
        center = _legacy_cube_center(cube)
        size = cube.get("size", [0.0, 0.0, 0.0])
        if center is None or not isinstance(size, list) or len(size) != 3:
            refined.append(cube)
            continue
        dist = math.sqrt(
            (center[0] - bone_pivot[0]) ** 2
            + (center[1] - bone_pivot[1]) ** 2
            + (center[2] - bone_pivot[2]) ** 2
        )
        max_dim = max(float(size[0]), float(size[1]), float(size[2]))
        if dist > 15.0 and max_dim > 20.0:
            continue
        refined.append(cube)
    if not refined:
        refined = cubes[:1]
    return refined


def _build_legacy_direct_one_cube(
    payload: bytes,
    tex_size: tuple[int, int] | None,
) -> dict[str, object] | None:
    records = _extract_legacy_direct_cube_records(payload, tex_size)
    if len(records) < 8:
        return None

    from collections import Counter
    from itertools import combinations

    x_counts = Counter(pos[0] for pos, _uv in records)
    y_counts = Counter(pos[1] for pos, _uv in records)
    z_counts = Counter(pos[2] for pos, _uv in records)
    x_vals = [v for v, _n in x_counts.most_common(8)]
    y_vals = [v for v, _n in y_counts.most_common(10)]
    z_vals = [v for v, _n in z_counts.most_common(10)]

    best_subset: list[tuple[tuple[float, float, float], tuple[int, int]]] | None = None
    best_score = -1
    best_bounds: tuple[float, float, float, float, float, float] | None = None
    for x_pair in combinations(x_vals, 2):
        for y_pair in combinations(y_vals, 2):
            for z_pair in combinations(z_vals, 2):
                subset = [
                    rec
                    for rec in records
                    if rec[0][0] in x_pair and rec[0][1] in y_pair and rec[0][2] in z_pair
                ]
                if len(subset) < 8:
                    continue
                uniq_pos = {pos for pos, _uv in subset}
                if len(uniq_pos) < 8:
                    continue
                score = len(subset) + len(uniq_pos) * 4
                if score > best_score:
                    best_score = score
                    best_subset = subset
                    best_bounds = (
                        min(x_pair),
                        max(x_pair),
                        min(y_pair),
                        max(y_pair),
                        min(z_pair),
                        max(z_pair),
                    )
    if best_subset is None or best_bounds is None:
        return None
    records = best_subset
    min_x, max_x, min_y, max_y, min_z, max_z = best_bounds

    def _face_recs(face: str) -> list[tuple[tuple[float, float, float], tuple[int, int]]]:
        out: list[tuple[tuple[float, float, float], tuple[int, int]]] = []
        for pos, uv in records:
            x, y, z = pos
            if face == "west" and abs(x - min_x) < 1e-4:
                out.append((pos, uv))
            elif face == "east" and abs(x - max_x) < 1e-4:
                out.append((pos, uv))
            elif face == "down" and abs(y - min_y) < 1e-4:
                out.append((pos, uv))
            elif face == "up" and abs(y - max_y) < 1e-4:
                out.append((pos, uv))
            elif face == "north" and abs(z - min_z) < 1e-4:
                out.append((pos, uv))
            elif face == "south" and abs(z - max_z) < 1e-4:
                out.append((pos, uv))
        return out

    def _select_face_uv_rect(
        face_records: list[tuple[tuple[float, float, float], tuple[int, int]]],
        expect_w: float,
        expect_h: float,
    ) -> tuple[list[int], list[int]] | None:
        by_pos: dict[tuple[float, float, float], set[tuple[int, int]]] = {}
        for pos, uv in face_records:
            by_pos.setdefault(pos, set()).add(uv)
        if len(by_pos) != 4:
            return None
        choices = [sorted(list(v)) for v in by_pos.values()]
        if any(not c for c in choices):
            return None

        best: tuple[float, int, int, int, int] | None = None
        for combo in itertools.product(*choices):
            us = sorted({uv[0] for uv in combo})
            vs = sorted({uv[1] for uv in combo})
            if len(us) != 2 or len(vs) != 2:
                continue
            width = us[1] - us[0]
            height = vs[1] - vs[0]
            if width <= 0 or height <= 0:
                continue
            # Prefer UV rectangles that match geometric face dimensions.
            err = abs(width - expect_w) + abs(height - expect_h)
            area = width * height
            if best is None:
                best = (err, area, us[0], vs[0], width, height)
                continue
            best_err, best_area, *_rest = best
            if err < best_err or (abs(err - best_err) < 1e-6 and area > best_area):
                best = (err, area, us[0], vs[0], width, height)
        if best is None:
            return None
        return [best[2], best[3]], [best[4], best[5]]

    uv_faces: dict[str, dict[str, list[int]]] = {}
    size_x = abs(max_x - min_x)
    size_y = abs(max_y - min_y)
    size_z = abs(max_z - min_z)
    face_expect = {
        "north": (size_x, size_y),
        "south": (size_x, size_y),
        "east": (size_z, size_y),
        "west": (size_z, size_y),
        "up": (size_x, size_z),
        "down": (size_x, size_z),
    }
    for face in ("north", "east", "south", "west", "up", "down"):
        face_records = _face_recs(face)
        exp_w, exp_h = face_expect[face]
        rect = _select_face_uv_rect(face_records, exp_w, exp_h)
        if rect is None:
            continue
        uv0, size = rect
        width, height = size
        if face == "down":
            uv_faces[face] = {"uv": [uv0[0], uv0[1] + height], "uv_size": [width, -height]}
        else:
            uv_faces[face] = {"uv": uv0, "uv_size": [width, height]}

    if len(uv_faces) < 4:
        return None

    return {
        "origin": [min_x, min_y, min_z],
        "size": [round(max_x - min_x, 5), round(max_y - min_y, 5), round(max_z - min_z, 5)],
        "uv": uv_faces,
    }


def _extract_legacy_model_bones(
    section: bytes,
    names: tuple[str, ...],
    *,
    codec_format: int | None,
) -> list[LegacyModelBoneInfo]:
    hits = _iter_len_prefixed_names(section)
    valid = set(names)
    first_hit: dict[str, int] = {}
    for off, name in hits:
        if name in valid and name not in first_hit:
            first_hit[name] = off

    parent_map: dict[str, str] = {}
    for off, parent in hits:
        if parent not in valid:
            continue
        nxt = off + 1 + len(parent) + 1
        if nxt >= len(section):
            continue
        child_len = section[nxt]
        child_end = nxt + 1 + child_len
        if not (1 <= child_len <= 32 and child_end < len(section) and section[child_end] == 0):
            continue
        try:
            child = section[nxt + 1:child_end].decode("ascii")
        except UnicodeDecodeError:
            continue
        if child in valid and child != parent and child not in parent_map:
            parent_map[child] = parent

    cube_count_guess: dict[str, int] = {}
    for off, name in hits:
        if not name.startswith("M"):
            continue
        visible = name[1:]
        if visible not in valid:
            continue
        second = section.find(bytes([len(name)]) + name.encode("ascii"), off + 1)
        if second < 0:
            continue
        data_off = second + 1 + len(name)
        if data_off < len(section) and section[data_off] == 0:
            data_off += 1
        if data_off + 2 > len(section):
            continue
        count = section[data_off]
        record_kind = section[data_off + 1]
        if 0 <= count <= 0x40 and record_kind in (0x05, 0x06, 0x07):
            cube_count_guess[visible] = count

    out: list[LegacyModelBoneInfo] = []
    for name in names:
        off = first_hit.get(name)
        pivot = _read_legacy_pivot(section, off, name) if off is not None else None
        wrapper_name = None
        uv_norm_hints: tuple[float, ...] = ()
        wrapper = _find_legacy_wrapper_payload(section, name)
        if wrapper is None and _LEGACY_WRAPPER_NAME_RE.fullmatch(name):
            wrapper = _find_legacy_wrapper_payload_by_wrapper(section, name)
        if wrapper is not None:
            wrapper_name, count, _kind, payload = wrapper
            if name not in cube_count_guess:
                cube_count_guess[name] = count
            uv_norm_hints = _extract_uv_norm_hints(payload)
        out.append(
            LegacyModelBoneInfo(
                name=name,
                parent=parent_map.get(name),
                pivot=pivot,
                cube_count_guess=cube_count_guess.get(name),
                wrapper_name=wrapper_name,
                uv_norm_hints=uv_norm_hints,
            )
        )
    existing = {bone.name for bone in out}
    if codec_format == 15:
        wrapper_names = [name for _off, name in hits if _LEGACY_WRAPPER_NAME_RE.fullmatch(name)]
        for wrapper_name in dict.fromkeys(wrapper_names):
            if len(wrapper_name) >= 2 and wrapper_name[1].isdigit():
                visible = wrapper_name
            elif wrapper_name.startswith("MM"):
                visible = wrapper_name
            elif re.search(r"M[0-9]+$", wrapper_name):
                visible = wrapper_name
            else:
                visible = wrapper_name[1:]
            if not visible or visible in existing:
                continue
            wrapper = _find_legacy_wrapper_payload_by_wrapper(section, wrapper_name)
            if wrapper is None:
                continue
            _wname, count, _kind, payload = wrapper
            if count <= 0:
                continue
            if not _build_legacy_face_quad_cubes(payload, (256, 128)):
                continue
            if visible in {"M2", "M3", "M4", "M5", "MM1", "FM1", "FM2"} or re.search(r"(Left|Right)M[0-9]+$", visible):
                parent = "Head"
            else:
                parent = "Head" if any(tok in visible for tok in ("Left", "Right", "H", "F", "G", "J")) else "AllBody"
            out.append(
                LegacyModelBoneInfo(
                    name=visible,
                    parent=parent,
                    pivot=None,
                    cube_count_guess=count,
                    wrapper_name=wrapper_name,
                    uv_norm_hints=_extract_uv_norm_hints(payload),
                )
            )
    return out


def _repair_legacy_bone_parents(
    bones: list[LegacyModelBoneInfo],
    *,
    codec_format: int | None,
) -> list[LegacyModelBoneInfo]:
    by_name = {bone.name: bone for bone in bones}
    repaired: list[LegacyModelBoneInfo] = []
    for bone in bones:
        parent = bone.parent
        if parent is None:
            if bone.name == "UpperBody" and "AllBody" in by_name:
                parent = "AllBody"
            elif bone.name == "Head" and "UpperBody" in by_name:
                parent = "UpperBody"
            elif bone.name == "Arm" and "UpperBody" in by_name:
                parent = "UpperBody"
            elif codec_format == 15:
                m = re.fullmatch(r"([HFGJ](?:Left|Right)M)(\d+)", bone.name)
                if m is not None:
                    prefix, idx_text = m.groups()
                    idx = int(idx_text)
                    anchor = f"{prefix}1"
                    if idx >= 2 and anchor in by_name:
                        parent = anchor
                    elif "Head" in by_name:
                        parent = "Head"
                elif bone.name == "FM2" and "FM1" in by_name:
                    parent = "FM1"
                elif bone.name in {"FM1", "MM1"} and "Head" in by_name:
                    parent = "Head"
                elif re.fullmatch(r"M[2-9]\d*", bone.name) and "Head" in by_name:
                    parent = "Head"
        if parent == bone.parent:
            repaired.append(bone)
        else:
            repaired.append(
                LegacyModelBoneInfo(
                    name=bone.name,
                    parent=parent,
                    pivot=bone.pivot,
                    cube_count_guess=bone.cube_count_guess,
                    wrapper_name=bone.wrapper_name,
                    uv_norm_hints=bone.uv_norm_hints,
                )
            )
    return repaired


def _prune_legacy_model_bones(
    bones: list[LegacyModelBoneInfo],
    *,
    codec_format: int | None,
    asset_name: str | None,
) -> list[LegacyModelBoneInfo]:
    if codec_format == 9 and asset_name in {"main_model", "arrow_model"}:
        return bones
    if len(bones) <= 96:
        return bones
    by_name = {bone.name: bone for bone in bones}
    keep: set[str] = set()
    for bone in bones:
        if bone.wrapper_name is not None or bone.cube_count_guess is not None:
            keep.add(bone.name)
        if bone.parent is not None:
            keep.add(bone.name)
            keep.add(bone.parent)
        if bone.pivot is not None and any(tok in bone.name for tok in _LEGACY_BONE_NAME_HINTS):
            keep.add(bone.name)
    changed = True
    while changed:
        changed = False
        for name in tuple(keep):
            bone = by_name.get(name)
            if bone and bone.parent and bone.parent not in keep:
                keep.add(bone.parent)
                changed = True
    pruned = [bone for bone in bones if bone.name in keep]
    return pruned or bones


def _legacy_model_identifier(section: bytes) -> str:
    m = re.search(rb"geometry\.[A-Za-z0-9_.-]+", section)
    if m is None:
        return "geometry.unknown"
    return m.group().decode("ascii", "replace")


def _legacy_model_texture_size(asset_name: str | None) -> tuple[int, int] | None:
    if asset_name in ("main_model", "arm_model"):
        return (256, 256)
    if asset_name == "arrow_model":
        return (64, 64)
    return None


def _format9_model_names(section: bytes, asset_name: str | None) -> tuple[str, ...]:
    names = tuple(dict.fromkeys(name for _off, name in _iter_len_prefixed_names(section)))
    if not names:
        names = tuple(dict.fromkeys(_extract_names(section, limit=256)))
        if not names:
            return tuple()
    if asset_name == "main_model":
        return tuple(name for name in names if name not in _FORMAT9_MAIN_MODEL_EXCLUDE_NAMES)
    if asset_name == "arm_model":
        broad = tuple(dict.fromkeys(_extract_names(section, limit=256)))
        return tuple(name for name in broad if name in _FORMAT9_ARM_MODEL_KEEP_NAMES)
    if asset_name == "arrow_model":
        broad = tuple(dict.fromkeys(_extract_names(section, limit=256)))
        keep_hits = sum(name in _FORMAT9_ARROW_MODEL_KEEP_NAMES for name in broad)
        if keep_hits >= 3:
            return tuple(name for name in broad if name in _FORMAT9_ARROW_MODEL_KEEP_NAMES)
        filtered: list[str] = []
        seen: set[str] = set()
        for name in broad:
            if name in _FORMAT9_ARROW_MODEL_EXCLUDE_NAMES:
                continue
            if name.startswith(("math.", "query.", "ysm.", "v.")):
                continue
            if "." in name or "-" in name:
                continue
            if re.fullmatch(r"[A-Z0-9]{2,5}", name):
                continue
            if name not in seen:
                seen.add(name)
                filtered.append(name)
        return tuple(filtered)
    return names


def _format9_arrow_signature_score(section: bytes) -> int:
    return sum(name.encode("ascii") in section for name in _FORMAT9_ARROW_MODEL_KEEP_NAMES)


def _select_format9_arrow_section(scan: LegacyScanResult, decoded: bytes) -> LegacySection | None:
    best: LegacySection | None = None
    best_key: tuple[int, int, int] | None = None
    for idx, sec in enumerate(scan.sections):
        section_bytes = decoded[sec.start:sec.end]
        score = _format9_arrow_signature_score(section_bytes)
        if score <= 0:
            continue
        prefer = 1 if sec.asset_guess != "main_model" else 0
        key = (prefer, score, -sec.size)
        if best_key is None or key > best_key:
            best = sec
            best_key = key
    if best_key is None:
        return None
    if best_key[1] < 3:
        return None
    return best


def _build_legacy_model_canonical_json(
    asset_name: str | None,
    section: bytes,
    names: tuple[str, ...],
    *,
    codec_format: int | None,
) -> dict[str, object]:
    # The section manifest keeps only a short preview of names; the full model
    # parser should re-scan the whole section so wrappers like MHead are not lost.
    if codec_format == 9:
        format9_names = _format9_model_names(section, asset_name)
        if format9_names:
            names = format9_names
        else:
            rich_names = tuple(dict.fromkeys(_extract_names(section, limit=256)))
            if rich_names:
                names = rich_names
    else:
        rich_names = tuple(dict.fromkeys(_extract_names(section, limit=256)))
        if rich_names:
            names = rich_names
    bones = _extract_legacy_model_bones(section, names, codec_format=codec_format)
    bones = _repair_legacy_bone_parents(bones, codec_format=codec_format)
    bones = _prune_legacy_model_bones(bones, codec_format=codec_format, asset_name=asset_name)
    tex = _legacy_model_texture_size(asset_name)
    bone_entries: list[dict[str, object]] = []
    for bone in bones:
        entry: dict[str, object] = {"name": bone.name}
        if bone.parent:
            entry["parent"] = bone.parent
        if bone.pivot is not None:
            entry["pivot"] = list(bone.pivot)
        if bone.cube_count_guess is not None:
            entry["__compiled_cube_count_guess"] = bone.cube_count_guess
        if bone.wrapper_name is not None:
            entry["__compiled_wrapper_name"] = bone.wrapper_name
        if bone.uv_norm_hints:
            entry["__compiled_uv_norm_hints"] = list(bone.uv_norm_hints)
        wrapper = None
        if bone.wrapper_name is not None and _LEGACY_WRAPPER_NAME_RE.fullmatch(bone.name):
            wrapper = _find_legacy_wrapper_payload_by_wrapper(section, bone.wrapper_name)
        if wrapper is None:
            wrapper = _find_legacy_wrapper_payload(section, bone.name)
        if wrapper is None:
            wrapper = _find_legacy_visible_payload_same_name(section, bone.name)
        if wrapper is None and bone.wrapper_name:
            wrapper = _find_legacy_wrapper_payload_by_wrapper(section, bone.wrapper_name)
        if wrapper is not None:
            payload = wrapper[3]
            if codec_format == 15 and wrapper[2] in (70, 77):
                nested = _unwrap_legacy_nested_wrapper_payload(payload)
                if nested is not None and nested[2] == 6:
                    payload = nested[3]
            cubes = _decode_legacy_payload_cubes(
                payload,
                tex,
                bone_name=bone.name,
                bone_pivot=bone.pivot,
                preferred_count=max(1, bone.cube_count_guess or 1),
            )
            if cubes:
                entry["cubes"] = cubes
            if codec_format == 15 and "cubes" not in entry:
                nested_visible = _unwrap_legacy_nested_visible_payload(payload)
                if nested_visible is None:
                    nested_visible = _unwrap_legacy_inline_visible_payload(payload)
                if nested_visible is not None:
                    nested_best = _find_legacy_best_named_payload(
                        section,
                        nested_visible[0],
                        nested_visible[3],
                    )
                    if nested_best is not None:
                        cubes = _decode_legacy_payload_cubes(
                            nested_best[3],
                            tex,
                            bone_name=bone.name,
                            bone_pivot=bone.pivot,
                            preferred_count=1,
                        )
                        if cubes:
                            entry["cubes"] = cubes
        if codec_format == 15 and "cubes" not in entry:
            container_slice = _find_legacy_single_visible_container_slice(section, bone.name)
            if container_slice is not None:
                nested_visible = _unwrap_legacy_nested_visible_payload(container_slice)
                if nested_visible is None:
                    nested_visible = _unwrap_legacy_inline_visible_payload(container_slice)
                if nested_visible is not None:
                    nested_best = _find_legacy_best_named_payload(
                        section,
                        nested_visible[0],
                        nested_visible[3],
                    )
                    if nested_best is not None:
                        cubes = _decode_legacy_payload_cubes(
                            nested_best[3],
                            tex,
                            bone_name=bone.name,
                            bone_pivot=bone.pivot,
                            preferred_count=1,
                        )
                        if cubes:
                            entry["cubes"] = cubes
        bone_entries.append(entry)

    if codec_format == 15:
        by_name = {entry["name"]: entry for entry in bone_entries}
        filtered_entries: list[dict[str, object]] = []
        for entry in bone_entries:
            name = entry["name"]
            parent_name = entry.get("parent")
            if (
                isinstance(name, str)
                and isinstance(parent_name, str)
                and re.fullmatch(r"^M[A-Za-z0-9_-]*M$", name)
                and entry.get("cubes")
            ):
                parent = by_name.get(parent_name)
                if parent is not None and parent.get("cubes"):
                    continue
            filtered_entries.append(entry)
    else:
        filtered_entries = bone_entries
    if codec_format == 9:
        filtered_entries = _postprocess_format9_model_entries(filtered_entries, asset_name=asset_name)

    description: dict[str, object] = {
        "identifier": _legacy_model_identifier(section),
    }
    if tex is not None:
        description["texture_width"] = tex[0]
        description["texture_height"] = tex[1]
    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [
            {
                "description": description,
                "bones": filtered_entries,
            }
        ],
    }


def _format9_pair_name(name: str) -> str | None:
    if name.startswith("Left"):
        return "Right" + name[4:]
    if name.startswith("Right"):
        return "Left" + name[5:]
    if name.startswith("Left_"):
        return "Right_" + name[5:]
    if name.startswith("Right_"):
        return "Left_" + name[6:]
    return None


def _swap_format9_entry_payload(a: dict[str, object], b: dict[str, object]) -> None:
    for key in (
        "pivot",
        "cubes",
        "__compiled_cube_count_guess",
        "__compiled_wrapper_name",
        "__compiled_uv_norm_hints",
    ):
        av = a.get(key)
        bv = b.get(key)
        if bv is None:
            a.pop(key, None)
        else:
            a[key] = bv
        if av is None:
            b.pop(key, None)
        else:
            b[key] = av


def _format9_entry_pivot_x(entry: dict[str, object]) -> float | None:
    pivot = entry.get("pivot")
    if isinstance(pivot, list) and len(pivot) == 3:
        return float(pivot[0])
    cubes = entry.get("cubes")
    if isinstance(cubes, list) and cubes:
        cube_pivot = cubes[0].get("pivot")
        if isinstance(cube_pivot, list) and len(cube_pivot) == 3:
            return float(cube_pivot[0])
    return None


def _format9_center_distance(
    cube: dict[str, object],
    pivot: list[float] | tuple[float, float, float] | None,
) -> float | None:
    center = _legacy_cube_center(cube)
    if center is None or pivot is None:
        return None
    return math.sqrt(
        (center[0] - float(pivot[0])) ** 2
        + (center[1] - float(pivot[1])) ** 2
        + (center[2] - float(pivot[2])) ** 2
    )


def _filter_format9_entry_cubes(entry: dict[str, object]) -> None:
    cubes = entry.get("cubes")
    if not isinstance(cubes, list) or not cubes:
        return
    if entry.get("name") == "gui":
        entry.pop("cubes", None)
        return
    pivot = entry.get("pivot")
    keep: list[dict[str, object]] = []
    for cube in cubes:
        size = cube.get("size")
        if not isinstance(size, list) or len(size) != 3:
            continue
        sx, sy, sz = (float(size[0]), float(size[1]), float(size[2]))
        max_dim = max(sx, sy, sz)
        min_dim = min(sx, sy, sz)
        if max_dim > 48.0 or min_dim <= 0.0:
            continue
        uv_faces = cube.get("uv", {})
        if isinstance(uv_faces, dict):
            bad_uv = False
            for face in uv_faces.values():
                if not isinstance(face, dict):
                    continue
                uv = face.get("uv")
                uv_size = face.get("uv_size")
                if isinstance(uv, list) and len(uv) == 2 and (float(uv[0]) < 0.0 or float(uv[1]) < 0.0):
                    bad_uv = True
                    break
                if isinstance(uv_size, list) and len(uv_size) == 2:
                    if abs(float(uv_size[0])) > 48.0 or abs(float(uv_size[1])) > 48.0:
                        bad_uv = True
                        break
            if bad_uv:
                continue
        dist = _format9_center_distance(cube, pivot)
        if dist is not None and dist > max(18.0, max_dim * 1.75) and max_dim > 3.0:
            continue
        keep.append(cube)
    if keep:
        entry["cubes"] = keep
    else:
        entry.pop("cubes", None)


def _postprocess_format9_model_entries(
    entries: list[dict[str, object]],
    *,
    asset_name: str | None,
) -> list[dict[str, object]]:
    by_name = {
        entry["name"]: entry
        for entry in entries
        if isinstance(entry.get("name"), str)
    }

    # Repair common missing visible-bone parents from the paired legacy sample.
    explicit_parent_rules = {
        "AllHead": "UpperBody",
        "bow": "UpperBody",
        "LeftEyelid": "Eyelid",
        "RightEyelid": "Eyelid",
        "LeftEyebrow": "EyeBrow",
        "RightEyebrow": "EyeBrow",
        "LeftEyePublic": "LeftEyelidBase",
        "RightEyePublic": "RightEyelidBase",
        "LeftEyeDot": "LeftEyelidBase",
        "RightEyeDot": "RightEyelidBase",
        "Left_ear": "Ear",
        "Right_ear": "Ear",
        "LeftArm": "Arm",
        "RightArm": "Arm",
        "LeftLeg": "Leg",
        "RightLeg": "Leg",
        "UpPl": "Root",
        "DownPl": "Root",
        "LeftPl": "Root",
        "RightPl": "Root",
        "Other": "Root",
        "Sakura": "Root",
        "Bowknot": "Other",
        "Bowknot2": "Other",
        "Bowknot3": "Other",
        "Bowknot4": "Other",
        "Bowknot5": "Other",
        "Board": "Other",
        "Brand": "Other",
        "Board2": "Board",
    }
    for entry in entries:
        name = entry.get("name")
        if not isinstance(name, str):
            continue
        wrapper_parent = f"M{name}"
        if wrapper_parent in by_name and (
            entry.get("parent") is None or name in {"Head", "UpperBody", "UpBody", "AllBody", "Tail"}
        ):
            entry["parent"] = wrapper_parent
            continue
        if entry.get("parent") is not None:
            continue
        parent = explicit_parent_rules.get(name)
        if parent is not None and parent in by_name:
            entry["parent"] = parent

    # Remove helper/container cubes that should live on visible children instead.
    child_map: dict[str, list[str]] = {}
    for entry in entries:
        parent = entry.get("parent")
        name = entry.get("name")
        if isinstance(parent, str) and isinstance(name, str):
            child_map.setdefault(parent, []).append(name)
    for entry in entries:
        name = entry.get("name")
        if not isinstance(name, str) or "cubes" not in entry:
            continue
        if name.startswith("M") and name[1:] in by_name:
            entry.pop("cubes", None)
            continue
        if name.endswith("Locator") or name in _FORMAT9_CONTAINER_BONE_NAMES:
            children = child_map.get(name, [])
            if any(by_name.get(child, {}).get("cubes") for child in children):
                entry.pop("cubes", None)
    if asset_name == "arm_model":
        filtered = []
        for entry in entries:
            name = entry.get("name")
            if isinstance(name, str) and name not in _FORMAT9_ARM_MODEL_KEEP_NAMES:
                continue
            filtered.append(entry)
        entries = filtered
        by_name = {
            entry["name"]: entry
            for entry in entries
            if isinstance(entry.get("name"), str)
        }
        if "Arm" not in by_name and ("LeftArm" in by_name or "RightArm" in by_name):
            arm_entry: dict[str, object] = {"name": "Arm"}
            entries.insert(0, arm_entry)
            by_name["Arm"] = arm_entry
            for child_name in ("LeftArm", "RightArm"):
                child = by_name.get(child_name)
                if child is not None:
                    child["parent"] = "Arm"
            if "LeftForeArm" in by_name:
                by_name["LeftForeArm"]["parent"] = "LeftArm"
            if "RightForeArm" in by_name:
                by_name["RightForeArm"]["parent"] = "RightArm"
            if "LeftHand" in by_name:
                by_name["LeftHand"]["parent"] = "LeftForeArm"
            if "RightHand" in by_name:
                by_name["RightHand"]["parent"] = "RightForeArm"
            if "LeftHandLocator" in by_name:
                by_name["LeftHandLocator"]["parent"] = "LeftHand"
            if "RightHandLocator" in by_name:
                by_name["RightHandLocator"]["parent"] = "RightHand"

    # Keep only locally plausible cubes on visible bones.
    for entry in entries:
        _filter_format9_entry_cubes(entry)

    # If a left/right pair landed on the wrong side, swap the geometry payloads.
    swapped: set[str] = set()
    for name, entry in by_name.items():
        if name in swapped:
            continue
        other_name = _format9_pair_name(name)
        if other_name is None or other_name not in by_name:
            continue
        other = by_name[other_name]
        x0 = _format9_entry_pivot_x(entry)
        x1 = _format9_entry_pivot_x(other)
        if x0 is None or x1 is None:
            continue
        if name.startswith("Left") and x0 < 0.0 and x1 > 0.0:
            _swap_format9_entry_payload(entry, other)
            swapped.add(name)
            swapped.add(other_name)
        elif name.startswith("Right") and x0 > 0.0 and x1 < 0.0:
            _swap_format9_entry_payload(entry, other)
            swapped.add(name)
            swapped.add(other_name)
        elif name.startswith("Left_") and x0 < 0.0 and x1 > 0.0:
            _swap_format9_entry_payload(entry, other)
            swapped.add(name)
            swapped.add(other_name)
        elif name.startswith("Right_") and x0 > 0.0 and x1 < 0.0:
            _swap_format9_entry_payload(entry, other)
            swapped.add(name)
            swapped.add(other_name)

    return entries


def _png_chunk(tag: bytes, data: bytes) -> bytes:
    return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", binascii.crc32(tag + data) & 0xFFFFFFFF)


def _encode_png_rgba(width: int, height: int, rgba: bytes) -> bytes:
    rows = []
    stride = width * 4
    for y in range(height):
        rows.append(b"\x00" + rgba[y * stride:(y + 1) * stride])
    raw = b"".join(rows)
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    return b"".join(
        (
            b"\x89PNG\r\n\x1a\n",
            _png_chunk(b"IHDR", ihdr),
            _png_chunk(b"IDAT", zlib.compress(raw, level=9)),
            _png_chunk(b"IEND", b""),
        )
    )


def _png_pixels_equal(png_a: bytes, png_b: bytes) -> bool:
    if png_a == png_b:
        return True
    if Image is None:
        return False
    try:
        import io

        img_a = Image.open(io.BytesIO(png_a)).convert("RGBA")
        img_b = Image.open(io.BytesIO(png_b)).convert("RGBA")
        return img_a.size == img_b.size and img_a.tobytes() == img_b.tobytes()
    except Exception:
        return False


def _rgba_alpha_score(buf: bytes) -> float:
    if len(buf) < 4:
        return 0.0
    alphas = buf[3::4]
    if not alphas:
        return 0.0
    opaque_like = sum(1 for b in alphas if b in (0x00, 0xFF))
    return opaque_like / len(alphas)


def _decode_legacy_texture_variant_40(decoded: bytes, label_off: int, label: bytes) -> tuple[int, int, int, bytes] | None:
    head_off = label_off + len(label)
    head = decoded[head_off : head_off + 4]
    if len(head) < 4 or head[2] != 0x40 or head[3] != 0x00:
        return None
    width = head[0] * 2
    height = head[1]
    if width <= 0 or height <= 0:
        return None
    payload_off = head_off + 99
    payload_len = width * height * 8
    payload = decoded[payload_off : payload_off + payload_len]
    if len(payload) != payload_len:
        return None
    row_stride = width * 4
    rows = [payload[i : i + row_stride] for i in range(0, payload_len, row_stride)]
    if len(rows) != height * 2:
        return None
    merged = bytearray()
    for even_row, odd_row in zip(rows[0::2], rows[1::2]):
        for i in range(0, row_stride, 4):
            a = even_row[i : i + 4]
            b = odd_row[i : i + 4]
            merged.extend(a if a[3] >= b[3] else b)
    return (width, height, payload_off, bytes(merged))


def _guess_legacy_texture_block(decoded: bytes, label_off: int, label: bytes, next_anchor: int | None) -> tuple[int, int] | None:
    start = label_off + len(label) + 3
    size_order = [512, 256, 128, 64, 32, 16]
    lower = label.lower()
    if lower == b"skin":
        size_order = [256, 128, 64, 512, 32, 16]
    elif b"arrow" in lower:
        size_order = [64, 32, 128, 16, 256]

    best: tuple[float, int, int] | None = None
    for dim in size_order:
        raw_len = dim * dim * 4
        end = start + raw_len
        if end > len(decoded):
            continue
        body = decoded[start:end]
        body_score = _rgba_alpha_score(body)
        if body_score < 0.70:
            continue
        tail = decoded[end:end + 256]
        tail_score = _rgba_alpha_score(tail) if tail else 0.0
        score = body_score - (tail_score * 0.35)
        if next_anchor is not None:
            gap = next_anchor - end
            if 0 <= gap <= 16:
                score += 0.75
        if best is None or score > best[0]:
            best = (score, dim, raw_len)
    if best is None:
        return None
    return (best[1], best[2])


def _export_legacy_textures(
    decoded: bytes,
    scan: LegacyScanResult,
    out_dir: Path,
    *,
    debug: bool = False,
    codec_format: int | None = None,
) -> list[LegacyTextureExport]:
    exports: list[LegacyTextureExport] = []
    texture_entries = [
        entry
        for entry in scan.directory_entries
        if entry.property_match == "arrow_texture" or (entry.property_match or "").startswith("texture")
    ]
    if not texture_entries:
        for asset in parse_property_assets(scan_file(scan.path, dump=False).property_text):
            if asset.tag != "texture":
                continue
            prop_name = asset.display_name
            if prop_name != "arrow_texture" and not prop_name.startswith("texture"):
                continue
            texture_entries.append(
                LegacyDirectoryEntry(
                    offset=-1,
                    control=tuple(),
                    name=asset.label or prop_name,
                    hash_hex=asset.hash_hex,
                    property_match=prop_name,
                )
            )
    label_offsets: dict[str, int] = {}
    for entry in texture_entries:
        label = (entry.name or "").encode("ascii", "replace")
        if not label:
            continue
        off = decoded.find(label)
        if off >= 0:
            label_offsets[entry.property_match or ""] = off

    sorted_offsets = sorted(label_offsets.values())
    for entry in texture_entries:
        asset_name = entry.property_match or ""
        label = (entry.name or "").encode("ascii", "replace")
        if not asset_name or not label:
            continue
        label_off = label_offsets.get(asset_name)
        if label_off is None:
            continue
        next_anchor = None
        for off in sorted_offsets:
            if off > label_off:
                next_anchor = off
                break
        special = _decode_legacy_texture_variant_40(decoded, label_off, label)
        if special is not None:
            width, height, start, rgba = special
            png = _encode_png_rgba(width, height, rgba)
            png_sha256 = hashlib.sha256(png).hexdigest()
            png_file = "texture.2.png" if asset_name == "arrow_texture" else "texture.png"
            (out_dir / png_file).write_bytes(png)
            exports.append(
                LegacyTextureExport(
                    asset_name=asset_name,
                    label=label.decode("ascii", "replace"),
                    width=width,
                    height=height,
                    offset=start,
                    raw_len=len(rgba),
                    png_file=png_file,
                    sha256=png_sha256,
                )
            )
            continue
        guessed = _guess_legacy_texture_block(decoded, label_off, label, next_anchor)
        if guessed is None:
            continue
        dim, raw_len = guessed
        start = label_off + len(label) + 3
        rgba = decoded[start:start + raw_len]
        png = _encode_png_rgba(dim, dim, rgba)
        png_sha256 = hashlib.sha256(png).hexdigest()
        png_file = "texture.2.png" if asset_name == "arrow_texture" else "texture.png"
        (out_dir / png_file).write_bytes(png)
        exports.append(
            LegacyTextureExport(
                asset_name=asset_name,
                label=label.decode("ascii", "replace"),
                width=dim,
                height=dim,
                offset=start,
                raw_len=raw_len,
                png_file=png_file,
                sha256=png_sha256,
            )
        )
    return exports


def _guess_legacy_texture_block_from_section(section: bytes) -> tuple[int, int] | None:
    best: tuple[float, int, int] | None = None
    for dim in (256, 128, 64):
        raw_len = dim * dim * 4
        if raw_len > len(section):
            continue
        for rel_off in range(0, len(section) - raw_len + 1, 0x100):
            body = section[rel_off : rel_off + raw_len]
            alpha = body[3::4]
            if not alpha:
                continue
            alpha_discrete = sum(1 for b in alpha if b in (0, 255)) / len(alpha)
            if alpha_discrete < 0.98:
                continue
            alpha_nonzero = sum(1 for b in alpha if b) / len(alpha)
            if alpha_nonzero < 0.01:
                continue
            rgb_nonzero = sum(1 for b in body[0::4] if b) / len(alpha)
            score = alpha_discrete + (alpha_nonzero * 3.0) + rgb_nonzero
            if best is None or score > best[0]:
                best = (score, dim, rel_off)
    if best is None:
        return None
    return (best[1], best[2])


def _export_legacy_textures_fallback(decoded: bytes, scan: LegacyScanResult, out_dir: Path) -> list[LegacyTextureExport]:
    assets = parse_property_assets(scan_file(scan.path, dump=False).property_text)
    texture_assets = [asset for asset in assets if asset.tag == "texture"]
    if not texture_assets:
        return []
    unnamed_sections = [
        sec
        for sec in scan.sections
        if sec.asset_guess is None and sec.kind_guess in ("model", "texture_or_binary", "unknown")
    ]
    if not unnamed_sections:
        return []
    target_section = max(unnamed_sections, key=lambda sec: sec.size)
    section_bytes = decoded[target_section.start : target_section.end]
    guessed = _guess_legacy_texture_block_from_section(section_bytes)
    if guessed is None:
        return []
    dim, rel_off = guessed
    raw_len = dim * dim * 4
    start = target_section.start + rel_off
    rgba = decoded[start : start + raw_len]
    png = _encode_png_rgba(dim, dim, rgba)
    asset = texture_assets[0]
    png_file = "texture.png"
    (out_dir / png_file).write_bytes(png)
    return [
        LegacyTextureExport(
            asset_name=asset.display_name,
            label=asset.label or asset.display_name,
            width=dim,
            height=dim,
            offset=start,
            raw_len=raw_len,
            png_file=png_file,
            sha256=hashlib.sha256(png).hexdigest(),
        )
    ]
    return {
        "format_version": "1.8.0",
        "__compiled_decompile": {
            "status": "signature_only",
            "asset_name": asset_name,
            "section_sha256": section_sha256,
            "clip_count_guess": len(token_names),
            "bone_name_count_guess": len(guessed_bones),
            "signature_score": int(signature_scores.get(asset_name, 0)),
            "notes": [
                "Recovered from compiled legacy YSM animation section.",
                "Clip names are inferred from embedded signature tokens.",
                "Durations, loop modes, and keyframe channels are not reconstructed yet.",
                "Bone lists are guessed from embedded strings.",
            ],
        },
        "animations": animations,
    }


def _find_directory_start(decoded: bytes, tail_start: int) -> int:
    window_start = max(0, tail_start - 0x40)
    marker = decoded.rfind(b"\x80\x01\x80\x01", tail_start, min(len(decoded), tail_start + 0x80000))
    if marker >= 0:
        return marker
    marker = decoded.rfind(b"\x80\x01\x80\x01", window_start, tail_start)
    if marker >= 0:
        return marker
    return tail_start


def _parse_legacy_directory(
    decoded: bytes, directory_start: int, property_by_hash: dict[str, str]
) -> tuple[str, tuple[LegacyDirectoryEntry, ...]]:
    if directory_start >= len(decoded):
        return "", tuple()
    off = directory_start
    prefix = ""
    if decoded[off : off + 4] == b"\x80\x01\x80\x01":
        prefix = decoded[off : off + 4].hex()
        off += 4

    entries: list[LegacyDirectoryEntry] = []
    while off < len(decoded):
        ctrl: tuple[int, ...]
        name = ""
        hash_off: int | None = None

        if (
            off + 66 <= len(decoded)
            and decoded[off + 1] == 0x40
            and HEX_HASH_RE.fullmatch(decoded[off + 2 : off + 66])
        ):
            ctrl = (decoded[off],)
            hash_off = off + 2
            next_off = off + 66
        elif (
            off + 67 <= len(decoded)
            and decoded[off + 2] == 0x40
            and HEX_HASH_RE.fullmatch(decoded[off + 3 : off + 67])
        ):
            ctrl = (decoded[off], decoded[off + 1])
            hash_off = off + 3
            next_off = off + 67
        elif off + 3 <= len(decoded):
            name_len = decoded[off + 1]
            name_end = off + 2 + name_len
            if (
                0 < name_len < 0x40
                and name_end + 65 <= len(decoded)
                and decoded[name_end] == 0x40
                and HEX_HASH_RE.fullmatch(decoded[name_end + 1 : name_end + 65])
            ):
                ctrl = (decoded[off], decoded[off + 1])
                name = decoded[off + 2 : name_end].decode("utf-8", "replace")
                hash_off = name_end + 1
                next_off = name_end + 65
            else:
                break
        else:
            break

        hash_hex = decoded[hash_off : hash_off + 64].decode("ascii")
        entries.append(
            LegacyDirectoryEntry(
                offset=off,
                control=ctrl,
                name=name,
                hash_hex=hash_hex,
                property_match=property_by_hash.get(hash_hex),
            )
        )
        off = next_off

    return prefix, tuple(entries)


def find_legacy_sections(decoded: bytes, tail_start: int) -> list[LegacySection]:
    starts = {0}
    for pat in SECTION_TAGS:
        start = 0
        while True:
            i = decoded.find(pat, start)
            if i < 0 or i >= tail_start:
                break
            starts.add(i)
            start = i + 1
    ordered = sorted(starts)
    filtered: list[int] = []
    for s in ordered:
        if not filtered or s - filtered[-1] > 0x800:
            filtered.append(s)
    filtered.append(tail_start)

    sections: list[LegacySection] = []
    for i, start in enumerate(filtered[:-1]):
        end = filtered[i + 1]
        if end <= start:
            continue
        chunk = decoded[start:end]
        if len(chunk) < 0x800:
            continue
        names = _extract_names(chunk)
        kind = _classify_section(chunk, names)
        sections.append(
            LegacySection(
                start=start,
                end=end,
                size=end - start,
                tag=int.from_bytes(chunk[:4], "little"),
                kind_guess=kind,
                names=names,
                asset_guess=None,
                sha256=__import__("hashlib").sha256(chunk).hexdigest(),
            )
        )
    return sections


def assign_property_names(sections: list[LegacySection], path: Path) -> list[LegacySection]:
    assets = parse_property_assets(scan_file(path, dump=False).property_text)
    pools: dict[str, list[str]] = {}
    for asset in assets:
        pools.setdefault(_property_kind(asset.tag), []).append(asset.display_name)

    assigned: list[LegacySection] = []
    for sec in sections:
        pool = pools.get(sec.kind_guess, [])
        guess = pool.pop(0) if pool else None
        assigned.append(
            LegacySection(
                start=sec.start,
                end=sec.end,
                size=sec.size,
                tag=sec.tag,
                kind_guess=sec.kind_guess,
                names=sec.names,
                asset_guess=guess,
                sha256=sec.sha256,
            )
        )
    return assigned


def scan_legacy_sections(path: Path) -> LegacyScanResult:
    result = decode_bom_v3(path)
    decoded = result.decompressed
    tail_markers = [m.start() for m in HEX_HASH_RE.finditer(decoded)]
    tail_start = min(tail_markers) if tail_markers else len(decoded)
    directory_start = _find_directory_start(decoded, tail_start)
    property_assets = parse_property_assets(scan_file(path, dump=False).property_text)
    property_by_hash = {asset.hash_hex: asset.display_name for asset in property_assets}
    directory_prefix, directory_entries = _parse_legacy_directory(decoded, directory_start, property_by_hash)
    sections = assign_property_names(find_legacy_sections(decoded, tail_start), path)
    return LegacyScanResult(
        path=path,
        codec_format=_read_property_format(path),
        decoded_len=len(decoded),
        tail_start=tail_start,
        directory_start=directory_start,
        directory_prefix=directory_prefix,
        directory_entries=directory_entries,
        sections=tuple(sections),
    )


def _prune_legacy_debug_outputs(out_dir: Path) -> None:
    for pattern in ("*.section.bin", "*.manifest.json", "*.decompiled.json", "legacy_sections.json"):
        for path in out_dir.glob(pattern):
            path.unlink(missing_ok=True)


def _clear_legacy_output_dir(out_dir: Path) -> None:
    for pattern in (
        "*.json",
        "*.png",
        "*.ogg",
        "*.section.bin",
        "*.manifest.json",
        "*.decompiled.json",
        "property.txt",
        "decoded.bin",
        "asset_bundle.json",
        "legacy_sections.json",
        "oracle_restore.json",
    ):
        for path in out_dir.glob(pattern):
            path.unlink(missing_ok=True)


def dump_legacy_sections(path: Path, scan: LegacyScanResult | None = None, *, debug: bool = False) -> Path:
    if scan is None:
        scan = scan_legacy_sections(path)
    result = decode_bom_v3(path)
    decoded = result.decompressed

    folder_name = _sanitize_name(_read_property_name(path) or path.stem)
    codec_format = scan.codec_format
    out_dir = path.with_name(f"{folder_name}_legacy_sections_format{codec_format or 'unknown'}")
    out_dir.mkdir(parents=True, exist_ok=True)
    _clear_legacy_output_dir(out_dir)

    manifest = {
        "source_file": str(path),
        "codec_format": codec_format,
        "decoded_len": scan.decoded_len,
        "tail_start": scan.tail_start,
        "directory_start": scan.directory_start,
        "directory_prefix": scan.directory_prefix,
        "directory_count": len(scan.directory_entries),
        "directory_entries": [
            {
                "offset": entry.offset,
                "control": list(entry.control),
                "name": entry.name,
                "hash_hex": entry.hash_hex,
                "property_match": entry.property_match,
            }
            for entry in scan.directory_entries
        ],
        "section_count": len(scan.sections),
        "texture_exports": [],
        "pretty_aliases": [],
        "sections": [],
    }

    used_aliases: set[str] = set()
    section_bytes_by_name: dict[str, bytes] = {}
    alias_candidates: list[dict[str, object]] = []
    format9_arrow_section = _select_format9_arrow_section(scan, decoded) if codec_format == 9 else None

    for idx, sec in enumerate(scan.sections):
        base = sec.asset_guess or f"legacy_{idx:02d}.{sec.kind_guess}"
        file_name = f"{_sanitize_name(base.replace('_', '.'))}.section.bin"
        out_path = out_dir / file_name
        section_bytes = decoded[sec.start:sec.end]
        out_path.write_bytes(section_bytes)
        section_bytes_by_name[file_name] = section_bytes
        if sec.asset_guess is not None:
            used_aliases.add(file_name)
        animation_headers = list(_parse_animation_headers(section_bytes)) if sec.kind_guess == "animation" else []
        ogg_off = section_bytes.find(b"OggS") if sec.kind_guess == "audio" else -1
        ogg_file = None
        if ogg_off >= 0:
            ogg_base = _sanitize_name(base.replace("_", "."))
            ogg_name = f"{ogg_base}.ogg"
            (out_dir / ogg_name).write_bytes(section_bytes[ogg_off:])
            ogg_file = ogg_name
        if sec.asset_guess is None:
            score_blob = section_bytes
            source_file = file_name
            source_offset = 0
            if ogg_off > 0x1000:
                prefix_name = f"{_sanitize_name(base.replace('_', '.'))}.prefix.section.bin"
                (out_dir / prefix_name).write_bytes(section_bytes[:ogg_off])
                section_bytes_by_name[prefix_name] = section_bytes[:ogg_off]
                score_blob = section_bytes[:ogg_off]
                source_file = prefix_name
                source_offset = 0
            alias_candidates.append(
                {
                    "ordinal": idx,
                    "source_file": source_file,
                    "source_offset": source_offset,
                    "scores": _legacy_signature_scores(score_blob),
                }
            )
        entry = {
            "ordinal": idx,
            "asset_guess": sec.asset_guess,
            "kind_guess": sec.kind_guess,
            "tag": sec.tag,
            "start": sec.start,
            "end": sec.end,
            "size": sec.size,
            "sha256": sec.sha256,
            "file": file_name,
            "names": list(sec.names),
            "animation_headers": animation_headers,
            "ogg_offset": ogg_off if ogg_off >= 0 else None,
            "ogg_file": ogg_file,
            "signature_scores": _legacy_signature_scores(section_bytes if ogg_off < 0 else section_bytes[:ogg_off] if ogg_off > 0x1000 else section_bytes),
        }
        manifest["sections"].append(entry)
        per_section_manifest = {
            "source_file": str(path),
            "codec_format": codec_format,
            "directory_start": scan.directory_start,
            "ordinal": idx,
            "asset_guess": sec.asset_guess,
            "kind_guess": sec.kind_guess,
            "tag": sec.tag,
            "start": sec.start,
            "end": sec.end,
            "size": sec.size,
            "sha256": sec.sha256,
            "file": file_name,
            "names": list(sec.names),
            "animation_headers": animation_headers,
            "ogg_offset": ogg_off if ogg_off >= 0 else None,
            "ogg_file": ogg_file,
            "signature_scores": entry["signature_scores"],
        }
        (out_dir / f"{file_name}.manifest.json").write_text(
            json.dumps(per_section_manifest, indent=2), encoding="utf-8"
        )
        if animation_headers:
            stub = build_animation_decompile_stub(
                asset_name=sec.asset_guess or base,
                section_sha256=sec.sha256,
                names=sec.names,
                animation_headers=animation_headers,
            )
            stub_text = json.dumps(stub, indent=2)
            if debug:
                (out_dir / _canonical_animation_stub_name(file_name)).write_text(
                    stub_text, encoding="utf-8"
                )
            canonical_name = _canonical_legacy_json_name(sec.asset_guess or "", "animation")
            if canonical_name is not None:
                (out_dir / canonical_name).write_text(
                    json.dumps(_strip_private_fields(stub), indent=2),
                    encoding="utf-8",
                )
        elif sec.kind_guess == "model":
            stub = build_model_decompile_stub(
                asset_name=sec.asset_guess or base,
                section_sha256=sec.sha256,
                names=sec.names,
            )
            if debug:
                stub_text = json.dumps(stub, indent=2)
                (out_dir / _canonical_model_stub_name(file_name)).write_text(
                    stub_text, encoding="utf-8"
                )
            canonical_name = _canonical_legacy_json_name(sec.asset_guess or "", "model")
            if canonical_name is not None:
                canonical_section = section_bytes
                canonical_names = sec.names
                if (
                    codec_format == 9
                    and sec.asset_guess == "arrow_model"
                    and format9_arrow_section is not None
                ):
                    canonical_section = decoded[format9_arrow_section.start : format9_arrow_section.end]
                    canonical_names = format9_arrow_section.names
                canonical_stub = _build_legacy_model_canonical_json(
                    sec.asset_guess,
                    canonical_section,
                    canonical_names,
                    codec_format=codec_format,
                )
                (out_dir / canonical_name).write_text(
                    json.dumps(_strip_private_fields(canonical_stub), indent=2), encoding="utf-8"
                )

    for asset_name in LEGACY_SIGNATURES:
        scored = sorted(
            (
                (
                    int(candidate["scores"].get(asset_name, 0)),
                    int(candidate["ordinal"]),
                    candidate["source_file"],
                )
                for candidate in alias_candidates
                if int(candidate["scores"].get(asset_name, 0)) > 0
            ),
            reverse=True,
        )
        if not scored:
            continue
        best_score, best_ordinal, best_source = scored[0]
        second_score = scored[1][0] if len(scored) > 1 else -1
        if best_score < 2 or best_score <= second_score:
            continue
        alias_name = f"{asset_name.replace('_', '.')}.section.bin"
        if alias_name in used_aliases:
            continue
        data = section_bytes_by_name.get(best_source)
        if data is None:
            continue
        (out_dir / alias_name).write_bytes(data)
        used_aliases.add(alias_name)
        source_entry = manifest["sections"][best_ordinal]
        if asset_name.endswith("_animation"):
            if source_entry["animation_headers"]:
                stub = build_animation_decompile_stub(
                    asset_name=asset_name,
                    section_sha256=str(source_entry["sha256"]),
                    names=tuple(str(n) for n in source_entry["names"]),
                    animation_headers=source_entry["animation_headers"],
                )
            else:
                stub = _build_legacy_animation_signature_stub(
                    asset_name=asset_name,
                    section_sha256=str(source_entry["sha256"]),
                    names=tuple(str(n) for n in source_entry["names"]),
                    signature_scores=dict(source_entry["signature_scores"]),
                )
            stub_text = json.dumps(stub, indent=2)
            if debug:
                (out_dir / _canonical_animation_stub_name(alias_name)).write_text(
                    stub_text, encoding="utf-8"
                )
            canonical_name = _canonical_legacy_json_name(asset_name, "animation")
            if canonical_name is not None:
                (out_dir / canonical_name).write_text(
                    json.dumps(_strip_private_fields(stub), indent=2),
                    encoding="utf-8",
                )
        elif asset_name.endswith("_model"):
            stub = build_model_decompile_stub(
                asset_name=asset_name,
                section_sha256=str(source_entry["sha256"]),
                names=tuple(str(n) for n in source_entry["names"]),
            )
            if debug:
                stub_text = json.dumps(stub, indent=2)
                (out_dir / _canonical_model_stub_name(alias_name)).write_text(
                    stub_text, encoding="utf-8"
                )
            canonical_name = _canonical_legacy_json_name(asset_name, "model")
            if canonical_name is not None:
                data = section_bytes_by_name.get(alias_name)
                if data is not None:
                    canonical_stub = _build_legacy_model_canonical_json(
                        asset_name,
                        data,
                        tuple(str(n) for n in source_entry["names"]),
                        codec_format=codec_format,
                    )
                    (out_dir / canonical_name).write_text(
                        json.dumps(_strip_private_fields(canonical_stub), indent=2), encoding="utf-8"
                    )
        manifest["pretty_aliases"].append(
            {
                "asset_name": asset_name,
                "alias_file": alias_name,
                "source_file": best_source,
                "source_section_ordinal": best_ordinal,
                "score": best_score,
            }
        )

    texture_exports = _export_legacy_textures(
        decoded,
        scan,
        out_dir,
        debug=debug,
        codec_format=codec_format,
    )
    if debug and not texture_exports:
        texture_exports = _export_legacy_textures_fallback(decoded, scan, out_dir)
    if not texture_exports:
        for stale_name in ("texture.png", "texture.2.png"):
            (out_dir / stale_name).unlink(missing_ok=True)
    manifest["texture_exports"] = [
        {
            "asset_name": item.asset_name,
            "label": item.label,
            "width": item.width,
            "height": item.height,
            "offset": item.offset,
            "raw_len": item.raw_len,
            "png_file": item.png_file,
            "sha256": item.sha256,
        }
        for item in texture_exports
    ]
    texture_sizes = {item.asset_name: (item.width, item.height) for item in texture_exports}
    main_tex_asset = next((name for name in texture_sizes if name != "arrow_texture"), None)
    for model_file, asset_name in (
        ("main.json", main_tex_asset),
        ("arm.json", main_tex_asset),
        ("arrow.json", "arrow_texture"),
    ):
        tex = texture_sizes.get(asset_name)
        model_path = out_dir / model_file
        if tex is None or not model_path.exists():
            continue
        try:
            model_obj = json.loads(model_path.read_text(encoding="utf-8"))
            geometry = model_obj.get("minecraft:geometry", [])
            if geometry and isinstance(geometry[0], dict):
                desc = geometry[0].setdefault("description", {})
                if isinstance(desc, dict):
                    desc["texture_width"] = tex[0]
                    desc["texture_height"] = tex[1]
                    model_path.write_text(json.dumps(model_obj, indent=2), encoding="utf-8")
        except Exception:
            pass

    (out_dir / "legacy_sections.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    if not debug:
        _prune_legacy_debug_outputs(out_dir)
    return out_dir


def print_legacy_sections(scan: LegacyScanResult) -> None:
    print(f"file: {scan.path}")
    print(f"codec_format: {scan.codec_format}")
    print(f"decoded_len: 0x{scan.decoded_len:x}")
    print(f"tail_start: 0x{scan.tail_start:x}")
    print(f"directory_start: 0x{scan.directory_start:x}")
    print(f"legacy_directory: {len(scan.directory_entries)}")
    for idx, entry in enumerate(scan.directory_entries[:12]):
        print(
            f"dir[{idx}]: control={list(entry.control)} name={entry.name!r} "
            f"property_match={entry.property_match!r}"
        )
    print(f"legacy_sections: {len(scan.sections)}")
    for idx, sec in enumerate(scan.sections):
        print(
            f"section[{idx}]: tag={sec.tag} kind={sec.kind_guess} "
            f"asset_guess={sec.asset_guess!r} start=0x{sec.start:x} len=0x{sec.size:x}"
        )
        if sec.names:
            print("  names: " + ", ".join(sec.names[:12]))


def main() -> None:
    ap = argparse.ArgumentParser(description="Heuristic legacy (format 9/15) payload section dumper")
    ap.add_argument("paths", nargs="+", type=Path)
    args = ap.parse_args()

    for path in args.paths:
        scan = scan_legacy_sections(path)
        print_legacy_sections(scan)
        out = dump_legacy_sections(path, scan)
        print(f"{path} -> {out}")


if __name__ == "__main__":
    main()
