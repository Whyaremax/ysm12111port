from __future__ import annotations

import argparse
from dataclasses import dataclass
from typing import Iterable, List


PATH_SEPARATOR = "/"
CURRENT_DIR = "."
PARENT_DIR = ".."
YSM_SUFFIX = ".ysm"


def merge_wrapped_path(left: str, right: str) -> str:
    """
    Conservative reference for merge_wrapped_records_into_dest() path joining.

    Proven from 0x0041a130:
    - append right onto left
    - insert separator byte 0x2f ('/') when left is non-empty
    """
    if not left:
        return right
    if not right:
        return left
    return left + PATH_SEPARATOR + right


def split_wrapped_path(path: str) -> List[str]:
    if not path:
        return []
    return [part for part in path.split(PATH_SEPARATOR) if part]


def normalize_wrapped_path(path: str) -> str:
    """
    Conservative POSIX-like normalization reference for the wrapped-path helpers.

    Proven from 0x00415720 / 0x0041a540:
    - segment metadata are walked component-by-component
    - '.' segments collapse
    - '..' segments backtrack one segment when possible
    - absolute-root semantics are not proven here, so keep this relative
    """
    parts: List[str] = []
    for part in split_wrapped_path(path):
        if part == CURRENT_DIR:
            continue
        if part == PARENT_DIR:
            if parts and parts[-1] != PARENT_DIR:
                parts.pop()
            else:
                parts.append(part)
            continue
        parts.append(part)
    return PATH_SEPARATOR.join(parts)


def relative_wrapped_path(target: str, base: str) -> str:
    """
    Conservative reference for serialize_wrapped_source_variant_a().

    0x0041a540 behaves like a relative-path builder:
    - normalize both descriptors
    - strip common prefix
    - emit '..' for remaining base components
    - append remaining target components
    - emit '.' when both normalize to the same descriptor
    """
    target_parts = split_wrapped_path(normalize_wrapped_path(target))
    base_parts = split_wrapped_path(normalize_wrapped_path(base))

    common = 0
    for left, right in zip(target_parts, base_parts):
        if left != right:
            break
        common += 1

    upward = [PARENT_DIR] * (len(base_parts) - common)
    downward = target_parts[common:]
    result = PATH_SEPARATOR.join(upward + downward)
    return result or CURRENT_DIR


def wrapped_leaf(path: str) -> str:
    """
    Conservative reference for serialize_wrapped_source_variant_b().

    Proven behavior:
    - empty input -> empty
    - slash-terminated input -> empty
    - otherwise return the final meaningful segment
    """
    if not path or path.endswith(PATH_SEPARATOR):
        return ""
    parts = split_wrapped_path(normalize_wrapped_path(path))
    return parts[-1] if parts else ""


def wrapped_parent_dir(path: str) -> str:
    """
    Conservative reference for the prefix extracted by FUN_0041b100()
    before FUN_005db290() calls FUN_00411120() to ensure directories exist.
    """
    normalized = normalize_wrapped_path(path)
    parts = split_wrapped_path(normalized)
    if len(parts) < 2:
        return ""
    return PATH_SEPARATOR.join(parts[:-1])


def append_literal_suffix(path: str, suffix: str) -> str:
    """
    Minimal reference for the observed suffix append path.

    Evidence:
    - 0x00417840 is called with literal data at 0x00140d0a
    - dumped bytes at 0x00140d0a start with '.ysm\\0'
    """
    return path + suffix


@dataclass(frozen=True)
class WrappedPathSet:
    base: str
    yes_steve_model: str
    custom: str
    auth: str
    builtin: str
    export: str
    cache: str
    server_index: str
    server: str
    client: str


def derive_wrapped_paths(base: str) -> WrappedPathSet:
    yes_steve_model = merge_wrapped_path(base, "yes_steve_model")
    custom = merge_wrapped_path(yes_steve_model, "custom")
    auth = merge_wrapped_path(yes_steve_model, "auth")
    builtin = merge_wrapped_path(yes_steve_model, "builtin")
    export = merge_wrapped_path(yes_steve_model, "export")
    cache = merge_wrapped_path(yes_steve_model, "cache")
    server_index = merge_wrapped_path(cache, "server_index")
    server = merge_wrapped_path(cache, "server")
    client = merge_wrapped_path(cache, "client")
    return WrappedPathSet(
        base=base,
        yes_steve_model=yes_steve_model,
        custom=custom,
        auth=auth,
        builtin=builtin,
        export=export,
        cache=cache,
        server_index=server_index,
        server=server,
        client=client,
    )


@dataclass(frozen=True)
class WrappedSerializationView:
    full_path: str
    relative_from_model_root: str
    leaf: str
    parent_dir: str


def derive_export_serialization_view(model_root: str, export_path: str) -> WrappedSerializationView:
    """
    Reference view for the builder-side wrapped path serialization around
    0x004c4e3f / 0x004c4f73.
    """
    normalized_export = normalize_wrapped_path(export_path)
    return WrappedSerializationView(
        full_path=normalized_export,
        relative_from_model_root=relative_wrapped_path(normalized_export, model_root),
        leaf=wrapped_leaf(normalized_export),
        parent_dir=wrapped_parent_dir(normalized_export),
    )


def build_argparser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Reference path derivation for the runtime-populated wrapped-source descriptors."
    )
    parser.add_argument("base", help="runtime base string later wrapped into yes_steve_model/... descriptors")
    parser.add_argument(
        "--export-path",
        help="optional concrete export path to show relative/leaf serialization behavior",
    )
    return parser


def main() -> None:
    args = build_argparser().parse_args()
    paths = derive_wrapped_paths(args.base)
    print(f"base: {paths.base}")
    print(f"yes_steve_model: {paths.yes_steve_model}")
    print(f"custom: {paths.custom}")
    print(f"auth: {paths.auth}")
    print(f"builtin: {paths.builtin}")
    print(f"export: {paths.export}")
    print(f"cache: {paths.cache}")
    print(f"server_index: {paths.server_index}")
    print(f"server: {paths.server}")
    print(f"client: {paths.client}")
    if args.export_path:
        view = derive_export_serialization_view(paths.yes_steve_model, args.export_path)
        print(f"export.full_path: {view.full_path}")
        print(f"export.relative_from_model_root: {view.relative_from_model_root}")
        print(f"export.leaf: {view.leaf}")
        print(f"export.parent_dir: {view.parent_dir}")


if __name__ == "__main__":
    main()
