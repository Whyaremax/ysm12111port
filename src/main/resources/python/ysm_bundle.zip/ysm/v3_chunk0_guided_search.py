from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

from provider1_chacha_reference import Provider1State, chacha_xor_stream, make_state_hchacha
from ysgp_end_to_end_extractor import _derive_subkey_variant, _xor_stream_variant
from ysgp_v3_exact_probe import (
    _apply_second_stage_variant,
    _parse_ysm_wrapper_block_header,
    _parse_zstd_block_header,
    _u32le,
    parse_v3_exact_input,
)


@dataclass(frozen=True)
class Chunk0Hypothesis:
    derivation_mode: str
    state_layout: str
    counter0: int
    rounds: int
    qword_mode: str
    second_stage: str


@dataclass
class Chunk0Result:
    score: int
    hyp: Chunk0Hypothesis
    prelude_skip: int
    section_offset: int
    wrapper_tag: int
    zstd_header_ok: bool
    zstd_block_type: int
    zstd_block_size: int
    wrapper_block_ok: bool
    wrapper_block_type: int
    wrapper_block_size: int
    head32: bytes


DERIVATION_MODES = (
    "confirmed_hchacha",
    "hchacha_tail_rol8",
    "hchacha_feedforward",
    "block_first8_raw",
    "block_first8_feedforward",
    "direct_key",
)

STATE_LAYOUTS = (
    "ctr64_nonce64",
    "ctr32_z_nonce64",
    "nonce64_ctr64",
    "z_ctr32_nonce64",
)

QWORD_MODES = (
    "raw",
    "raw_bswap",
    "zero",
    "outer_hash",
    "outer_hash_bswap",
    "secondary_lo",
    "secondary_hi",
)

SECOND_STAGE_MODES = (
    "none",
    "mt19937_64_xor",
    "mt19937_64_xor_be",
    "mt19937_64_phase1",
    "mt19937_64_phase2",
    "mt19937_64_phase3",
    "mt19937_64_phase4",
    "mt19937_64_phase5",
    "mt19937_64_phase6",
    "mt19937_64_phase7",
    "mt19937_64_be_phase1",
    "mt19937_64_be_phase2",
    "mt19937_64_be_phase3",
    "mt19937_64_be_phase4",
    "mt19937_64_be_phase5",
    "mt19937_64_be_phase6",
    "mt19937_64_be_phase7",
    "mt19937_64_skip1",
    "mt19937_64_skip2",
    "mt19937_64_skip4",
)


def _bswap64(v: int) -> int:
    return int.from_bytes(v.to_bytes(8, "little"), "big")


def _qword_for_mode(inp, mode: str) -> int:
    raw = int.from_bytes(inp.key56[48:56], "little")
    if mode == "raw":
        return raw
    if mode == "raw_bswap":
        return _bswap64(raw)
    if mode == "zero":
        return 0
    if mode == "outer_hash":
        return inp.outer_hash
    if mode == "outer_hash_bswap":
        return _bswap64(inp.outer_hash)
    if mode == "secondary_lo":
        return int.from_bytes(inp.key56[32:40], "little")
    if mode == "secondary_hi":
        return int.from_bytes(inp.key56[40:48], "little")
    raise ValueError(f"unsupported qword mode {mode}")


def _decrypt_prefix(inp, hyp: Chunk0Hypothesis, prefix_len: int) -> bytes:
    enc = inp.ciphertext[:prefix_len]
    key32 = inp.key56[:32]
    secondary16 = inp.key56[32:48]
    secondary_qword64 = _qword_for_mode(inp, hyp.qword_mode)

    if (
        hyp.derivation_mode == "confirmed_hchacha"
        and hyp.state_layout == "ctr64_nonce64"
        and hyp.counter0 == 0
    ):
        state = make_state_hchacha(
            key32=key32,
            secondary16=secondary16,
            secondary_qword64=secondary_qword64,
            rounds=hyp.rounds,
        )
        stage1 = chacha_xor_stream(state, enc)
    else:
        subkey32 = _derive_subkey_variant(key32, secondary16, hyp.rounds, hyp.derivation_mode)
        stage1 = _xor_stream_variant(
            key_or_subkey32=subkey32,
            secondary_qword64=secondary_qword64,
            rounds=hyp.rounds,
            src=enc,
            layout=hyp.state_layout,
            counter0=hyp.counter0,
        )

    return _apply_second_stage_variant(inp.key56, stage1, hyp.second_stage)


def _score_prefix(pt: bytes, hyp: Chunk0Hypothesis) -> Chunk0Result:
    if len(pt) < 16:
        return Chunk0Result(-10_000, hyp, 0, 0, 0, False, -1, -1, False, -1, -1, b"")

    prelude_skip = int.from_bytes(pt[:2], "little") & 0x3FF
    section_offset = 2 + prelude_skip
    if section_offset + 12 > len(pt):
        return Chunk0Result(-9_000, hyp, prelude_skip, section_offset, 0, False, -1, -1, False, -1, -1, b"")

    wrapper_tag = _u32le(pt, section_offset)
    zstd_header_ok, zstd_block_type, zstd_block_size = _parse_zstd_block_header(pt[section_offset:])
    wrapper_block_ok, wrapper_block_type, wrapper_block_size = _parse_ysm_wrapper_block_header(pt[section_offset:])
    head32 = pt[section_offset:section_offset + 32]

    score = 0
    if wrapper_tag == 0xFD2FB528:
        score += 2000
    elif (wrapper_tag & 0xFFFFFFF0) == 0x184D2A50:
        score += 1200

    if prelude_skip <= 0x100:
        score += 50
    elif prelude_skip <= 0x400:
        score += 10
    else:
        score -= 30

    if zstd_header_ok:
        score += 800
    if wrapper_block_ok:
        score += 1200
    if zstd_block_type == 0:
        score += 50
    if 0 <= zstd_block_size <= 131072:
        score += 1000
        if zstd_block_size <= 65536:
            score += 100
    elif zstd_block_size > 0:
        score -= min(600, zstd_block_size // 4096)

    return Chunk0Result(
        score=score,
        hyp=hyp,
        prelude_skip=prelude_skip,
        section_offset=section_offset,
        wrapper_tag=wrapper_tag,
        zstd_header_ok=zstd_header_ok,
        zstd_block_type=zstd_block_type,
        zstd_block_size=zstd_block_size,
        wrapper_block_ok=wrapper_block_ok,
        wrapper_block_type=wrapper_block_type,
        wrapper_block_size=wrapper_block_size,
        head32=head32,
    )


def search_chunk0(
    path: Path,
    *,
    prefix_len: int,
    counter_max: int,
    round_start: int,
    round_stop: int,
    round_step: int,
    derivation_modes: tuple[str, ...],
    state_layouts: tuple[str, ...],
    qword_modes: tuple[str, ...],
    second_stage_modes: tuple[str, ...],
) -> list[Chunk0Result]:
    inp = parse_v3_exact_input(path)
    results: list[Chunk0Result] = []

    for derivation_mode in derivation_modes:
        for state_layout in state_layouts:
            for qword_mode in qword_modes:
                for counter0 in range(counter_max + 1):
                    for rounds in range(round_start, round_stop + 1, round_step):
                        if rounds <= 0 or (rounds & 1):
                            continue
                        for second_stage in second_stage_modes:
                            hyp = Chunk0Hypothesis(
                                derivation_mode=derivation_mode,
                                state_layout=state_layout,
                                counter0=counter0,
                                rounds=rounds,
                                qword_mode=qword_mode,
                                second_stage=second_stage,
                            )
                            try:
                                pt = _decrypt_prefix(inp, hyp, prefix_len)
                            except Exception:
                                continue
                            results.append(_score_prefix(pt, hyp))

    results.sort(key=lambda r: r.score, reverse=True)
    return results


def main() -> None:
    ap = argparse.ArgumentParser(description="Bounded chunk-0 search for BOM v3 1:1 progress.")
    ap.add_argument("path", type=Path)
    ap.add_argument("--prefix-len", type=lambda s: int(s, 0), default=0x1000)
    ap.add_argument("--counter-max", type=int, default=31)
    ap.add_argument("--round-start", type=int, default=2)
    ap.add_argument("--round-stop", type=int, default=40)
    ap.add_argument("--round-step", type=int, default=2)
    ap.add_argument("--top", type=int, default=20)
    ap.add_argument("--derivation", action="append", choices=DERIVATION_MODES)
    ap.add_argument("--layout", action="append", choices=STATE_LAYOUTS)
    ap.add_argument("--qword-mode", action="append", choices=QWORD_MODES)
    ap.add_argument("--stage2", action="append", choices=SECOND_STAGE_MODES)
    ap.add_argument("--stage2-skip-max", type=int, default=-1)
    ap.add_argument("--stage2-phase-max", type=int, default=-1)
    args = ap.parse_args()

    stage2_modes = list(args.stage2 or SECOND_STAGE_MODES)
    if args.stage2_skip_max >= 0:
        for i in range(args.stage2_skip_max + 1):
            label = "mt19937_64_xor" if i == 0 else f"mt19937_64_skip{i}"
            if label not in stage2_modes:
                stage2_modes.append(label)
    if args.stage2_phase_max >= 0:
        for i in range(args.stage2_phase_max + 1):
            if i == 0:
                le_label = "mt19937_64_xor"
                be_label = "mt19937_64_xor_be"
            else:
                le_label = f"mt19937_64_phase{i}"
                be_label = f"mt19937_64_be_phase{i}"
            if le_label not in stage2_modes:
                stage2_modes.append(le_label)
            if be_label not in stage2_modes:
                stage2_modes.append(be_label)

    results = search_chunk0(
        args.path,
        prefix_len=args.prefix_len,
        counter_max=args.counter_max,
        round_start=args.round_start,
        round_stop=args.round_stop,
        round_step=args.round_step,
        derivation_modes=tuple(args.derivation or DERIVATION_MODES),
        state_layouts=tuple(args.layout or STATE_LAYOUTS),
        qword_modes=tuple(args.qword_mode or QWORD_MODES),
        second_stage_modes=tuple(stage2_modes),
    )
    print(f"file: {args.path}")
    print(f"results: {len(results)}")
    for i, r in enumerate(results[: args.top], 1):
        print(
            f"[{i}] score={r.score} skip={r.prelude_skip} off=0x{r.section_offset:x} "
            f"tag=0x{r.wrapper_tag:08x} zstd_hdr={int(r.zstd_header_ok)} "
            f"blk={r.zstd_block_type} size={r.zstd_block_size} "
            f"wblk_ok={int(r.wrapper_block_ok)} wblk={r.wrapper_block_type} wsize={r.wrapper_block_size} "
            f"der={r.hyp.derivation_mode} layout={r.hyp.state_layout} "
            f"ctr0={r.hyp.counter0} rounds={r.hyp.rounds} qword={r.hyp.qword_mode} "
            f"stage2={r.hyp.second_stage}"
        )
        print(f"    head32={r.head32.hex()}")


if __name__ == "__main__":
    main()
