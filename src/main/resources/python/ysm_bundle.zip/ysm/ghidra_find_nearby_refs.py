# Finds instructions whose operands mention addresses/scalars near a target.
# @category YSM

from ghidra.program.model.scalar import Scalar
from ghidra.program.model.address import Address


def parse_addr(text):
    if text.startswith("0x") or text.startswith("0X"):
        text = text[2:]
    return toAddr(text)


args = getScriptArgs()
target = parse_addr(args[0])
radius = int(args[1], 0) if len(args) > 1 else 0x200

lo = target.subtract(radius)
hi = target.add(radius)

listing = currentProgram.getListing()
fm = currentProgram.getFunctionManager()
count = 0

print("TARGET %s radius=0x%x" % (target, radius))

insn = listing.getInstructions(True)
while insn.hasNext():
    i = insn.next()
    matched = False
    for op_idx in range(i.getNumOperands()):
        objs = i.getOpObjects(op_idx)
        for obj in objs:
            if isinstance(obj, Address):
                if obj.compareTo(lo) >= 0 and obj.compareTo(hi) <= 0:
                    matched = True
            elif isinstance(obj, Scalar):
                try:
                    val = obj.getUnsignedValue()
                    addr = toAddr(val)
                    if addr.compareTo(lo) >= 0 and addr.compareTo(hi) <= 0:
                        matched = True
                except:
                    pass
    if matched:
        fn = fm.getFunctionContaining(i.getAddress())
        fn_name = fn.getName() if fn else "<no_func>"
        print("%s %s %s" % (i.getAddress(), fn_name, i))
        count += 1
        if count >= 200:
            print("TRUNCATED")
            break

print("MATCHES %d" % count)
