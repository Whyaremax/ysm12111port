#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json
from pathlib import Path


DEFAULT_TABLE_OFFSET = 0x163B34
DEFAULT_COUNT = 96


def read_c_string(blob: bytes, off: int, limit: int = 160) -> str:
    if off < 0 or off >= len(blob):
        return ""
    end = blob.find(b"\x00", off, min(len(blob), off + limit))
    if end == -1:
        end = min(len(blob), off + limit)
    raw = blob[off:end]
    try:
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return ""


def dump_table(blob: bytes, start: int, count: int) -> list[dict[str, object]]:
    rows = []
    for idx in range(count):
        off = start + idx * 8
        if off + 8 > len(blob):
            break
        str_off = int.from_bytes(blob[off : off + 4], "little")
        code_off = int.from_bytes(blob[off + 4 : off + 8], "little")
        if not (0 <= str_off < len(blob)):
            break
        rows.append(
            {
                "index": idx,
                "table_off": hex(off),
                "string_off": hex(str_off),
                "code_off": hex(code_off),
                "string": read_c_string(blob, str_off),
            }
        )
    return rows


def main() -> None:
    ap = argparse.ArgumentParser(description="Dump candidate string/code tables from latest YSM lib")
    ap.add_argument("binary", nargs="?", default="libysm-core-2.6.2-forge+mc1.20.1.so")
    ap.add_argument("--table-off", type=lambda s: int(s, 0), default=DEFAULT_TABLE_OFFSET)
    ap.add_argument("--count", type=int, default=DEFAULT_COUNT)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    blob = Path(args.binary).read_bytes()
    rows = dump_table(blob, args.table_off, args.count)

    if args.json:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return

    for row in rows:
        print(
            f"{row['index']:03d} "
            f"table={row['table_off']} "
            f"str={row['string_off']} "
            f"code={row['code_off']} "
            f"{row['string']!r}"
        )


if __name__ == "__main__":
    main()
