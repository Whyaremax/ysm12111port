# Finds instructions whose operands resolve exactly to the target addresses.
# @category YSM

from ghidra.program.model.scalar import Scalar
from ghidra.program.model.address import Address


def parse_addr(text):
    if text.startswith("0x") or text.startswith("0X"):
        text = text[2:]
    return toAddr(text)


targets = [parse_addr(arg) for arg in getScriptArgs()]
target_set = set(str(t) for t in targets)

listing = currentProgram.getListing()
fm = currentProgram.getFunctionManager()
count = 0

print("TARGETS %s" % ", ".join(str(t) for t in targets))

insn_iter = listing.getInstructions(True)
while insn_iter.hasNext():
    insn = insn_iter.next()
    matched = []
    for op_idx in range(insn.getNumOperands()):
        objs = insn.getOpObjects(op_idx)
        for obj in objs:
            if isinstance(obj, Address):
                if str(obj) in target_set:
                    matched.append(str(obj))
            elif isinstance(obj, Scalar):
                try:
                    val = obj.getUnsignedValue()
                    addr = toAddr(val)
                    if str(addr) in target_set:
                        matched.append(str(addr))
                except:
                    pass
    if matched:
        fn = fm.getFunctionContaining(insn.getAddress())
        fn_name = fn.getName() if fn else "<no_func>"
        print("%s %s %s TARGETS=%s" % (insn.getAddress(), fn_name, insn, ",".join(sorted(set(matched)))))
        count += 1
        if count >= 500:
            print("TRUNCATED")
            break

print("MATCHES %d" % count)
