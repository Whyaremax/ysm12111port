#@category YSM

from ghidra.app.decompiler import DecompInterface
from ghidra.program.model.symbol import RefType


def parse_addr(text):
    if text.startswith("0x") or text.startswith("0X"):
        text = text[2:]
    return toAddr(text)


def get_func(addr_text):
    addr = parse_addr(addr_text)
    func = getFunctionContaining(addr)
    if func is None:
        func = getFunctionAt(addr)
    return func


def decompile(func):
    ifc = DecompInterface()
    ifc.openProgram(currentProgram)
    res = ifc.decompileFunction(func, 60, monitor)
    if not res.decompileCompleted():
        print("DECOMP_FAIL %s" % func.getEntryPoint())
        return
    print("===== DECOMPILE %s %s =====" % (func.getName(), func.getEntryPoint()))
    print(res.getDecompiledFunction().getC())


def dump_calls(func):
    print("===== CALLS %s %s =====" % (func.getName(), func.getEntryPoint()))
    listing = currentProgram.getListing()
    insn = listing.getInstructionAt(func.getEntryPoint())
    end = func.getBody().getMaxAddress()
    while insn is not None and insn.getAddress().compareTo(end) <= 0:
        flow = insn.getFlows()
        if flow is not None and len(flow) > 0 and insn.getFlowType().isCall():
            for target in flow:
                callee = getFunctionAt(target)
                name = callee.getName() if callee is not None else "<no-func>"
                print("%s -> %s %s" % (insn.getAddress(), target, name))
        insn = insn.getNext()


def dump_refs(addr_text):
    addr = parse_addr(addr_text)
    print("===== REFS %s =====" % addr)
    refs = list(getReferencesTo(addr))
    refs.sort(key=lambda r: r.getFromAddress())
    for ref in refs:
        print("%s -> %s %s" % (ref.getFromAddress(), ref.getToAddress(), ref.getReferenceType()))


def dump_data(addr_text, size):
    addr = parse_addr(addr_text)
    print("===== DATA %s size=0x%x =====" % (addr, size))
    data = getBytes(addr, size)
    if data is None:
        print("NO_DATA")
        return
    print("".join("%02x" % (b & 0xff) for b in data))


args = getScriptArgs()
mode = args[0]

if mode == "func":
    for addr_text in args[1:]:
        func = get_func(addr_text)
        if func is None:
            print("NOFUNC %s" % addr_text)
            continue
        print("===== FUNC %s %s =====" % (func.getName(), func.getEntryPoint()))
        decompile(func)
elif mode == "refs":
    for addr_text in args[1:]:
        dump_refs(addr_text)
elif mode == "calls":
    for addr_text in args[1:]:
        func = get_func(addr_text)
        if func is None:
            print("NOFUNC %s" % addr_text)
            continue
        dump_calls(func)
elif mode == "data":
    dump_data(args[1], int(args[2], 0))
else:
    print("unknown mode")
