from __future__ import annotations

import argparse
import itertools
import json
import math
import struct
from pathlib import Path

from bom_v3_legacy_sections import _find_legacy_wrapper_payload


def _iter_uv_records(payload: bytes, tex_w: int, tex_h: int) -> list[tuple[int, tuple[float, float, float, int, int]]]:
    out: list[tuple[int, tuple[float, float, float, int, int]]] = []
    seen: set[tuple[int, int, int, int, int]] = set()
    for start in range(20):
        for off in range(start, len(payload) - 20, 20):
            x, y, z, u, v = struct.unpack_from("<5f", payload, off)
            if not all(math.isfinite(n) for n in (x, y, z, u, v)):
                continue
            if max(abs(x), abs(y), abs(z)) > 4.0:
                continue
            ui = int(round(u * tex_w))
            vi = int(round(v * tex_h))
            if abs((u * tex_w) - ui) > 0.05 or abs((v * tex_h) - vi) > 0.05:
                continue
            if not (0 <= ui <= tex_w and 0 <= vi <= tex_h):
                continue
            key = (round(x * 1_000_000), round(y * 1_000_000), round(z * 1_000_000), ui, vi)
            if key in seen:
                continue
            seen.add(key)
            out.append((off, (x, y, z, ui, vi)))
    return sorted(out)


def _load_source_face(source_json: Path, bone_name: str, face: str) -> tuple[list[tuple[float, float]], dict]:
    obj = json.loads(source_json.read_text())
    cube = None
    for geom in obj.get("minecraft:geometry", []):
        for bone in geom.get("bones", []):
            if bone.get("name") == bone_name and bone.get("cubes"):
                cube = bone["cubes"][0]
                break
    if cube is None:
        raise SystemExit(f"bone {bone_name!r} with one cube not found in {source_json}")

    ox, oy, oz = cube["origin"]
    sx, sy, sz = cube["size"]
    px, py, pz = cube.get("pivot", [0.0, 0.0, 0.0])
    rx, ry, rz = cube.get("rotation", [0.0, 0.0, 0.0])
    if abs(ry) > 1e-6 or abs(rz) > 1e-6:
        raise SystemExit("probe currently only supports X-rotation source cubes")

    import math as _m

    rr = _m.radians(rx)
    def rot_x(y: float, z: float) -> tuple[float, float]:
        dy = y - py
        dz = z - pz
        return (dy * _m.cos(rr) - dz * _m.sin(rr) + py, dy * _m.sin(rr) + dz * _m.cos(rr) + pz)

    verts = {
        "west": [(oy, oz), (oy, oz + sz), (oy + sy, oz), (oy + sy, oz + sz)],
        "east": [(oy, oz), (oy, oz + sz), (oy + sy, oz), (oy + sy, oz + sz)],
        "up": [(oy + sy, oz), (oy + sy, oz + sz), (oy + sy, oz), (oy + sy, oz + sz)],
        "down": [(oy, oz), (oy, oz + sz), (oy, oz), (oy, oz + sz)],
    }
    pts = [rot_x(y, z) for y, z in verts[face]]
    return pts, cube


def _fit_affine(raw_yz: list[tuple[float, float]], dst_yz: list[tuple[float, float]]) -> tuple[float, tuple[int, ...], tuple[float, ...]]:
    import numpy as np

    best = None
    for perm in itertools.permutations(range(len(raw_yz))):
        A = []
        B = []
        for i, j in enumerate(perm):
            ry, rz = raw_yz[i]
            dy, dz = dst_yz[j]
            A.append([ry, rz, 1.0, 0.0, 0.0, 0.0])
            A.append([0.0, 0.0, 0.0, ry, rz, 1.0])
            B.append(dy)
            B.append(dz)
        A = np.array(A, dtype=float)
        B = np.array(B, dtype=float)
        coeff, _res, _rank, _s = np.linalg.lstsq(A, B, rcond=None)
        pred = A @ coeff
        err = float(np.sqrt(np.mean((pred - B) ** 2)))
        if best is None or err < best[0]:
            best = (err, perm, tuple(float(x) for x in coeff))
    assert best is not None
    return best


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("section_bin", type=Path)
    ap.add_argument("bone_name")
    ap.add_argument("--texture-width", type=int, default=256)
    ap.add_argument("--texture-height", type=int, default=256)
    ap.add_argument("--source-json", type=Path)
    ap.add_argument("--face", default="west")
    args = ap.parse_args()

    section = args.section_bin.read_bytes()
    wrapper = _find_legacy_wrapper_payload(section, args.bone_name)
    if wrapper is None:
        raise SystemExit(f"wrapper for {args.bone_name!r} not found")
    wrapper_name, count, kind, payload = wrapper

    records = _iter_uv_records(payload, args.texture_width, args.texture_height)
    print(f"wrapper={wrapper_name} count={count} kind={kind} payload_len={len(payload)}")
    print(f"uv_records={len(records)}")
    for off, rec in records[:40]:
        x, y, z, u, v = rec
        print(f"{off:#06x} raw=({x:.6f},{y:.6f},{z:.6f}) uv=({u},{v}) scaled16=({x*16:.5f},{y*16:.5f},{z*16:.5f})")

    if args.source_json is None:
        return

    # Face-specific fit against a paired source model.
    src_face, cube = _load_source_face(args.source_json, args.bone_name, args.face)
    face_rect = cube["uv"][args.face]
    u0, v0 = face_rect["uv"]
    w, h = face_rect["uv_size"]
    u1 = u0 + abs(w)
    v1 = v0 + abs(h)
    wanted = {(u0, v0), (u1, v0), (u0, v1), (u1, v1)}
    face_records = [(off, rec) for off, rec in records if (rec[3], rec[4]) in wanted]
    if len(face_records) < 4:
        raise SystemExit(f"not enough records for face {args.face}: found {len(face_records)}")
    face_records = face_records[:4]
    raw_yz = [(rec[1], rec[2]) for _off, rec in face_records]
    err, perm, coeff = _fit_affine(raw_yz, src_face)
    print(f"fit_face={args.face} err={err:.9f} perm={perm}")
    print(
        "affine:",
        {
            "Y": [round(coeff[0], 9), round(coeff[1], 9), round(coeff[2], 9)],
            "Z": [round(coeff[3], 9), round(coeff[4], 9), round(coeff[5], 9)],
        },
    )
    for off, rec in face_records:
        x, y, z, u, v = rec
        yy = y * coeff[0] + z * coeff[1] + coeff[2]
        zz = y * coeff[3] + z * coeff[4] + coeff[5]
        print(f"mapped {off:#06x}: X={x*16:.5f} Y={yy:.5f} Z={zz:.5f} uv=({u},{v})")


if __name__ == "__main__":
    main()
