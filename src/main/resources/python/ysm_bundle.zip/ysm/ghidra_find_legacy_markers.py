# Dumps references to strings that look relevant to legacy model/animation payload parsing.
# @category YSM

from ghidra.program.model.symbol import RefType
from ghidra.util import Msg

PATTERNS = [
    "geometry",
    "animation",
    "format",
    "codec",
    "json",
    "png",
    "ogg",
    "arrow",
    "skin",
    "main",
    "arm",
    "extra",
    "carryon",
    "tac",
]


def normalize(s):
    try:
        return s.encode("ascii", "ignore").decode("ascii")
    except:
        return str(s)


def interesting(text):
    lower = text.lower()
    for pat in PATTERNS:
        if pat in lower:
            return True
    return False


def main():
    listing = currentProgram.getListing()
    refs = currentProgram.getReferenceManager()
    fm = currentProgram.getFunctionManager()
    matches = []

    for data in listing.getDefinedData(True):
        try:
            value = data.getValue()
            if value is None:
                continue
            text = normalize(str(value))
            if not interesting(text):
                continue
            addr = data.getAddress()
            users = []
            for ref in refs.getReferencesTo(addr):
                from_addr = ref.getFromAddress()
                fn = fm.getFunctionContaining(from_addr)
                fn_name = "<no_func>"
                if fn is not None:
                    fn_name = fn.getName()
                users.append("%s <- %s @ %s" % (addr, fn_name, from_addr))
            matches.append((addr, text, users))
        except:
            pass

    print("MATCH_COUNT=%d" % len(matches))
    for addr, text, users in matches:
        print("STRING %s %r" % (addr, text[:200]))
        if not users:
            print("  REF <none>")
        else:
            for user in users[:20]:
                print("  REF %s" % user)


if __name__ == "__main__":
    main()
