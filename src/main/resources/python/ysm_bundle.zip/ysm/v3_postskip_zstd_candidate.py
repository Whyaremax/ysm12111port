from __future__ import annotations

import argparse
import shutil
import subprocess
import tempfile
from pathlib import Path

from mt19937_64_reference import MT19937_64
from v3_seed_mix_reference import SECOND_STAGE_SEED_KEY, mix56_exact
from ysgp_v3_exact_probe import decrypt_v3_reader_exact, parse_v3_exact_input


ZSTD_FRAME_MAGIC = 0xFD2FB528


def _parse_zstd_frame(buf: bytes) -> dict[str, int] | None:
    if len(buf) < 9:
        return None
    if int.from_bytes(buf[:4], "little") != ZSTD_FRAME_MAGIC:
        return None

    desc = buf[4]
    single_segment = (desc >> 5) & 1
    checksum_flag = (desc >> 2) & 1
    dict_id_flag = desc & 0x3
    fcs_flag = desc >> 6

    off = 5
    window_desc = None
    if not single_segment:
        window_desc = buf[off]
        off += 1

    dict_id_len = (0, 1, 2, 4)[dict_id_flag]
    dict_id = int.from_bytes(buf[off:off + dict_id_len], "little") if dict_id_len else 0
    off += dict_id_len

    if fcs_flag == 0:
        fcs_len = 1 if single_segment else 0
    elif fcs_flag == 1:
        fcs_len = 2
    elif fcs_flag == 2:
        fcs_len = 4
    else:
        fcs_len = 8

    frame_content_size = int.from_bytes(buf[off:off + fcs_len], "little") if fcs_len else 0
    off += fcs_len
    if len(buf) < off + 3:
        return None

    block_header = int.from_bytes(buf[off:off + 3], "little")
    return {
        "descriptor": desc,
        "single_segment": single_segment,
        "checksum_flag": checksum_flag,
        "dict_id_flag": dict_id_flag,
        "dict_id": dict_id,
        "fcs_flag": fcs_flag,
        "frame_content_size": frame_content_size,
        "window_desc": -1 if window_desc is None else window_desc,
        "block_header_offset": off,
        "block_last": block_header & 1,
        "block_type": (block_header >> 1) & 0x3,
        "block_size": block_header >> 3,
    }


def _try_zstd(buf: bytes) -> tuple[int, str]:
    zstd = shutil.which("zstd")
    if zstd is None:
        return 127, "zstd not found"

    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp.write(buf)
        tmp_path = Path(tmp.name)
    try:
        proc = subprocess.run(
            [zstd, "-d", "-q", "-c", str(tmp_path)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )
        return proc.returncode, proc.stderr.strip()
    finally:
        tmp_path.unlink(missing_ok=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("file", type=Path)
    ap.add_argument("--dump", action="store_true")
    args = ap.parse_args()

    inp = parse_v3_exact_input(args.file)
    stage1 = decrypt_v3_reader_exact(inp)
    seed = mix56_exact(inp.key56, SECOND_STAGE_SEED_KEY)
    stage2 = MT19937_64.from_seed(seed).xor_stream(stage1)
    skip = int.from_bytes(stage2[:2], "little") & 0x3FF
    postskip = stage2[2 + skip:]

    print(f"file: {args.file}")
    print(f"skip: {skip}")
    print(f"postskip_len: 0x{len(postskip):x}")
    print(f"postskip_head32: {postskip[:32].hex()}")

    info = _parse_zstd_frame(postskip)
    if info is None:
        print("zstd_frame: no")
    else:
        print("zstd_frame: yes")
        print(f"frame.descriptor: 0x{info['descriptor']:02x}")
        print(f"frame.single_segment: {info['single_segment']}")
        print(f"frame.checksum_flag: {info['checksum_flag']}")
        print(f"frame.dict_id_flag: {info['dict_id_flag']}")
        print(f"frame.dict_id: {info['dict_id']}")
        print(f"frame.fcs_flag: {info['fcs_flag']}")
        print(f"frame.frame_content_size: {info['frame_content_size']}")
        print(f"frame.window_desc: {info['window_desc']}")
        print(f"block.header_offset: 0x{info['block_header_offset']:x}")
        print(f"block.last: {info['block_last']}")
        print(f"block.type: {info['block_type']}")
        print(f"block.size: {info['block_size']}")
        rc, msg = _try_zstd(postskip)
        print(f"zstd_rc: {rc}")
        print(f"zstd_msg: {msg or '-'}")

    if args.dump:
        out = args.file.with_suffix(args.file.suffix + ".postskip.zstcand")
        out.write_bytes(postskip)
        print(f"dump: {out}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
