#@category YSM

def parse_addr(text):
    if text.startswith("0x") or text.startswith("0X"):
        text = text[2:]
    return toAddr(text)


args = getScriptArgs()
start = parse_addr(args[0])
count = int(args[1], 0) if len(args) > 1 else 32

listing = currentProgram.getListing()
insn = listing.getInstructionAt(start)
if insn is None:
    insn = listing.getInstructionAfter(start)

printed = 0
while insn is not None and printed < count:
    raw = "".join("%02x" % (b & 0xff) for b in insn.getBytes())
    print("%s  %s  %s" % (insn.getAddress(), insn.toString(), raw))
    insn = insn.getNext()
    printed += 1
