from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from provider1_chacha_reference import (
    Provider1State,
    chacha_block_from_state,
    hchacha20_like_32,
)


TEXT_IMAGE_BASE = 0x100000


def _slice_at_text_va(image: bytes, va: int, size: int) -> bytes:
    off = va - TEXT_IMAGE_BASE
    if off < 0 or off + size > len(image):
        raise ValueError(f"VA 0x{va:x} size 0x{size:x} not in first text image")
    return image[off:off + size]


@dataclass(frozen=True)
class Provider1SelftestVectors:
    hchacha_key32: bytes
    hchacha_input16: bytes
    hchacha_rounds: int
    hchacha_expected32: bytes
    bulk_key32: bytes
    bulk_counter64: int
    bulk_tail_qword64: int
    bulk_rounds: int
    bulk_expected_keystream64: bytes


def load_vectors(lib_path: Path) -> Provider1SelftestVectors:
    image = lib_path.read_bytes()
    return Provider1SelftestVectors(
        hchacha_key32=_slice_at_text_va(image, 0x13C5D0, 16) + _slice_at_text_va(image, 0x13AB00, 16),
        hchacha_input16=_slice_at_text_va(image, 0x13CE60, 16),
        hchacha_rounds=8,
        hchacha_expected32=_slice_at_text_va(image, 0x16A3BF + 1, 32),
        bulk_key32=_slice_at_text_va(image, 0x135F30, 16) + _slice_at_text_va(image, 0x137DF0, 16),
        bulk_counter64=0x00000000FFFFFFFF,
        bulk_tail_qword64=0x8786858483828180,
        bulk_rounds=8,
        bulk_expected_keystream64=_slice_at_text_va(image, 0x16A45F + 1, 64),
    )


def run_selftests(v: Provider1SelftestVectors) -> list[tuple[str, bool, str]]:
    results: list[tuple[str, bool, str]] = []

    out32 = hchacha20_like_32(v.hchacha_key32, v.hchacha_input16, v.hchacha_rounds)
    results.append(
        (
            "slot+0x28 hchacha32",
            out32 == v.hchacha_expected32,
            out32.hex(),
        )
    )

    state = Provider1State(
        key_or_subkey32=v.bulk_key32,
        counter64=v.bulk_counter64,
        secondary_qword64=v.bulk_tail_qword64,
        rounds=v.bulk_rounds,
    )
    keystream64 = chacha_block_from_state(state)
    results.append(
        (
            "slot+0x20 keystream64",
            keystream64 == v.bulk_expected_keystream64,
            keystream64.hex(),
        )
    )

    prefix_ok = True
    for n in range(1, 65):
        state = Provider1State(
            key_or_subkey32=v.bulk_key32,
            counter64=v.bulk_counter64,
            secondary_qword64=v.bulk_tail_qword64,
            rounds=v.bulk_rounds,
        )
        got = chacha_block_from_state(state)[:n]
        if got != v.bulk_expected_keystream64[:n]:
            prefix_ok = False
            break
    results.append(("slot+0x20 prefix lengths 1..64", prefix_ok, "prefix-checked"))
    return results


def main() -> int:
    lib_path = Path("libysm-core-2.6.2-forge+mc1.20.1.so")
    vectors = load_vectors(lib_path)
    results = run_selftests(vectors)
    failed = False
    for name, ok, detail in results:
        print(f"{name}: {'PASS' if ok else 'FAIL'}")
        print(f"  {detail}")
        if not ok:
            failed = True
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
