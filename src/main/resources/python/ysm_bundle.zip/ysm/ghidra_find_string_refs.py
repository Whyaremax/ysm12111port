# Finds exact string occurrences in memory and prints incoming refs plus nearby funcs.
# @category YSM

from ghidra.program.model.address import Address


def to_bytes(text):
    try:
        return text.encode("utf-8")
    except:
        return bytes(text)


def iter_matches(pat):
    mem = currentProgram.getMemory()
    for block in mem.getBlocks():
        start = block.getStart()
        end = block.getEnd()
        addr = mem.findBytes(start, pat, None, True, None)
        while addr is not None and addr.compareTo(end) <= 0:
            yield (block, addr)
            nxt = addr.add(1)
            if nxt.compareTo(end) > 0:
                break
            addr = mem.findBytes(nxt, pat, None, True, None)


def main():
    args = getScriptArgs()
    refs = currentProgram.getReferenceManager()
    fm = currentProgram.getFunctionManager()

    for text in args:
        pat = to_bytes(text)
        print("STRING %r" % text)
        found = False
        for block, addr in iter_matches(pat):
            found = True
            print("  AT %s in %s" % (addr, block.getName()))
            shown = 0
            for ref in refs.getReferencesTo(addr):
                fn = fm.getFunctionContaining(ref.getFromAddress())
                fn_name = fn.getName() if fn else "<no_func>"
                print("    REF %s @ %s %s" % (fn_name, ref.getFromAddress(), ref.getReferenceType()))
                shown += 1
                if shown >= 50:
                    print("    REFS_TRUNCATED")
                    break
        if not found:
            print("  <none>")


if __name__ == "__main__":
    main()
