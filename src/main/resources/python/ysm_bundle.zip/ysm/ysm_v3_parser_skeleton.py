from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


class ParseError(ValueError):
    pass


def _u16le(data: bytes, off: int) -> int:
    return int.from_bytes(data[off:off + 2], "little")


def _u32le(data: bytes, off: int) -> int:
    return int.from_bytes(data[off:off + 4], "little")


def _u64le(data: bytes, off: int) -> int:
    return int.from_bytes(data[off:off + 8], "little")


def _slice(data: bytes, off: int, size: int) -> bytes:
    end = off + size
    if end > len(data):
        raise ParseError(f"slice {off:#x}+{size:#x} exceeds buffer size {len(data):#x}")
    return data[off:end]


@dataclass(frozen=True)
class SsoString64View:
    ptr: int
    length: int
    inline_or_cap_raw: bytes
    raw: bytes

    @classmethod
    def parse(cls, record: bytes, off: int) -> "SsoString64View":
        raw = _slice(record, off, 0x18)
        return cls(
            ptr=_u64le(record, off + 0x00),
            length=_u64le(record, off + 0x08),
            inline_or_cap_raw=_slice(record, off + 0x10, 0x08),
            raw=raw,
        )


@dataclass(frozen=True)
class OwnedBlob24:
    q0: int
    q1: int
    q2: int
    raw: bytes

    @classmethod
    def parse(cls, record: bytes, off: int) -> "OwnedBlob24":
        raw = _slice(record, off, 0x18)
        return cls(
            q0=_u64le(record, off + 0x00),
            q1=_u64le(record, off + 0x08),
            q2=_u64le(record, off + 0x10),
            raw=raw,
        )


@dataclass(frozen=True)
class OptionalBlock160:
    header_qword: int
    pod_10: bytes
    text: SsoString64View
    raw: bytes

    @classmethod
    def parse(cls, record: bytes, off: int) -> "OptionalBlock160":
        raw = _slice(record, off, 0x38)
        return cls(
            header_qword=_u64le(record, off + 0x00),
            pod_10=_slice(record, off + 0x08, 0x10),
            text=SsoString64View.parse(record, off + 0x18),
            raw=raw,
        )


@dataclass(frozen=True)
class Record160:
    vtbl: int
    main_text: SsoString64View
    scalar_028: int
    scalar_030: int
    opt0_present: bool
    opt0: Optional[OptionalBlock160]
    opt1_present: bool
    opt1: Optional[OptionalBlock160]
    opt2_present: bool
    opt2: Optional[OptionalBlock160]
    value_0f8: int
    blob_100: OwnedBlob24
    blob_118: OwnedBlob24
    blob_130: OwnedBlob24
    tail_148_raw: bytes
    raw: bytes

    SIZE = 0x160

    @classmethod
    def parse(cls, record: bytes) -> "Record160":
        if len(record) != cls.SIZE:
            raise ParseError(f"record160 must be exactly {cls.SIZE:#x} bytes")

        opt0_present = record[0x70] != 0
        opt1_present = record[0xB0] != 0
        opt2_present = record[0xF0] != 0

        return cls(
            vtbl=_u64le(record, 0x00),
            main_text=SsoString64View.parse(record, 0x08),
            scalar_028=_u64le(record, 0x28),
            scalar_030=_u32le(record, 0x30),
            opt0_present=opt0_present,
            opt0=OptionalBlock160.parse(record, 0x38) if opt0_present else None,
            opt1_present=opt1_present,
            opt1=OptionalBlock160.parse(record, 0x78) if opt1_present else None,
            opt2_present=opt2_present,
            opt2=OptionalBlock160.parse(record, 0xB8) if opt2_present else None,
            value_0f8=_u16le(record, 0xF8),
            blob_100=OwnedBlob24.parse(record, 0x100),
            blob_118=OwnedBlob24.parse(record, 0x118),
            blob_130=OwnedBlob24.parse(record, 0x130),
            tail_148_raw=_slice(record, 0x148, 0x18),
            raw=record,
        )


@dataclass(frozen=True)
class Record180View:
    raw_000_018: bytes
    child0_018: bytes
    holder0_038_raw: bytes
    child1_058: bytes
    holder1_070_raw: bytes
    child2_090: bytes
    holder2_0a8_raw: bytes
    tail_wrapper_0c8: bytes
    tail_child0_0d0: bytes
    tail_holder0_0e8_raw: bytes
    tail_child1_108: bytes
    tail_holder1_120_raw: bytes
    tail_child2_140: bytes
    tail_holder2_158_raw: bytes
    has_tail_178: bool
    raw_179_180: bytes
    raw: bytes

    SIZE = 0x180

    @classmethod
    def parse(cls, record: bytes) -> "Record180View":
        if len(record) != cls.SIZE:
            raise ParseError(f"record180 must be exactly {cls.SIZE:#x} bytes")
        return cls(
            raw_000_018=_slice(record, 0x000, 0x018),
            child0_018=_slice(record, 0x018, 0x020),
            holder0_038_raw=_slice(record, 0x038, 0x020),
            child1_058=_slice(record, 0x058, 0x018),
            holder1_070_raw=_slice(record, 0x070, 0x020),
            child2_090=_slice(record, 0x090, 0x018),
            holder2_0a8_raw=_slice(record, 0x0A8, 0x020),
            tail_wrapper_0c8=_slice(record, 0x0C8, 0x008),
            tail_child0_0d0=_slice(record, 0x0D0, 0x018),
            tail_holder0_0e8_raw=_slice(record, 0x0E8, 0x020),
            tail_child1_108=_slice(record, 0x108, 0x018),
            tail_holder1_120_raw=_slice(record, 0x120, 0x020),
            tail_child2_140=_slice(record, 0x140, 0x018),
            tail_holder2_158_raw=_slice(record, 0x158, 0x020),
            has_tail_178=record[0x178] != 0,
            raw_179_180=_slice(record, 0x179, 0x007),
            raw=record,
        )


def parse_record160_array(blob: bytes) -> list[Record160]:
    if len(blob) % Record160.SIZE != 0:
        raise ParseError("record160 array length is not a multiple of 0x160")
    return [
        Record160.parse(blob[i:i + Record160.SIZE])
        for i in range(0, len(blob), Record160.SIZE)
    ]


def parse_record180_array(blob: bytes) -> list[Record180View]:
    if len(blob) % Record180View.SIZE != 0:
        raise ParseError("record180 array length is not a multiple of 0x180")
    return [
        Record180View.parse(blob[i:i + Record180View.SIZE])
        for i in range(0, len(blob), Record180View.SIZE)
    ]
