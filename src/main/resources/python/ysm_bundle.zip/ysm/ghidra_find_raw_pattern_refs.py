# Finds raw byte patterns in memory and prints nearby functions that reference them.
# @category YSM

from ghidra.program.model.address import AddressSet

PATTERNS = [
    b"gui",
    b"attacked",
    b"boat",
    b"climbing",
    b"death",
    b"geometry.unknown",
    b"MRoot",
]


def iter_matches(block, pat):
    mem = currentProgram.getMemory()
    start = block.getStart()
    end = block.getEnd()
    addr = mem.findBytes(start, pat, None, True, None)
    while addr is not None and addr.compareTo(end) <= 0:
        yield addr
        nxt = addr.add(1)
        if nxt.compareTo(end) > 0:
            break
        addr = mem.findBytes(nxt, pat, None, True, None)


def main():
    listing = currentProgram.getListing()
    refs = currentProgram.getReferenceManager()
    fm = currentProgram.getFunctionManager()
    mem = currentProgram.getMemory()

    for pat in PATTERNS:
        print("PATTERN %r" % pat)
        found = False
        for block in mem.getBlocks():
            for addr in iter_matches(block, pat):
                found = True
                print("  AT %s in %s" % (addr, block.getName()))
                shown = 0
                for ref in refs.getReferencesTo(addr):
                    fn = fm.getFunctionContaining(ref.getFromAddress())
                    fn_name = fn.getName() if fn else "<no_func>"
                    print("    REF %s @ %s" % (fn_name, ref.getFromAddress()))
                    shown += 1
                    if shown >= 20:
                        break
        if not found:
            print("  <none>")


if __name__ == "__main__":
    main()
